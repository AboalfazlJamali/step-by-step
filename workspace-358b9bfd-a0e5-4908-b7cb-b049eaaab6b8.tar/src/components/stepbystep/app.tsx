"use client";

import { useCallback, useEffect, useState, useSyncExternalStore } from "react";
import { toast } from "sonner";
import { useTheme } from "next-themes";
import {
  Footprints,
  LayoutDashboard,
  CalendarDays,
  ListChecks,
  Sprout,
  Target,
  TrendingUp,
  Sun,
  Moon,
} from "lucide-react";
import type { LucideIcon } from "lucide-react";
import { Button } from "@/components/ui/button";
import {
  NAV_TABS,
  formatJalali,
  todayISO,
} from "@/lib/stepbystep";
import type {
  TabId,
  Task,
  Habit,
  Goal,
  ScheduleBlock,
  Stats,
} from "@/lib/stepbystep";
import { DashboardView } from "./views/dashboard";
import { ScheduleView } from "./views/schedule";
import { TasksView } from "./views/tasks";
import { HabitsView } from "./views/habits";
import { GoalsView } from "./views/goals";
import { ProgressView } from "./views/progress";
import { cn } from "@/lib/utils";

/* --------------------------------- data layer --------------------------------- */

export interface NewTaskInput {
  title: string;
  description?: string;
  category: string;
  priority: string;
  dueDate: string | null;
}

export interface NewBlockInput {
  date: string;
  startTime: string;
  endTime: string;
  title: string;
  category: string;
  note?: string;
}

export interface AppActions {
  addTask: (input: NewTaskInput) => Promise<boolean>;
  toggleTask: (task: Task) => void;
  deleteTask: (id: string) => void;
  addBlock: (input: NewBlockInput) => Promise<boolean>;
  toggleBlock: (block: ScheduleBlock) => void;
  deleteBlock: (id: string) => void;
  setSelectedDate: (iso: string) => void;
  addHabit: (input: { title: string; icon: string; targetDays: number }) => Promise<boolean>;
  toggleHabit: (habitId: string, date: string) => void;
  deleteHabit: (id: string) => void;
  addGoal: (input: { title: string; target: number; unit: string }) => Promise<boolean>;
  changeGoalProgress: (goal: Goal, delta: number) => void;
  deleteGoal: (id: string) => void;
}

export interface ViewProps {
  today: string;
  tasks: Task[];
  habits: Habit[];
  goals: Goal[];
  stats: Stats | null;
  blocksByDate: Record<string, ScheduleBlock[]>;
  selectedDate: string;
  actions: AppActions;
  navigate: (tab: TabId) => void;
}

async function api<T>(url: string, init?: RequestInit): Promise<T> {
  const res = await fetch(url, {
    ...init,
    headers: { "Content-Type": "application/json", ...(init?.headers ?? {}) },
  });
  const data = (await res.json().catch(() => ({}))) as T & { error?: string };
  if (!res.ok) throw new Error(data.error || "خطایی رخ داد؛ دوباره تلاش کن");
  return data;
}

const TAB_ICONS: Record<TabId, LucideIcon> = {
  dashboard: LayoutDashboard,
  schedule: CalendarDays,
  tasks: ListChecks,
  habits: Sprout,
  goals: Target,
  progress: TrendingUp,
};

/* --------------------------------- component --------------------------------- */

const subscribeNoop = () => () => {};

export function StepByStepApp() {
  // hydration-safe "is mounted" flag (no setState-in-effect needed)
  const mounted = useSyncExternalStore(
    subscribeNoop,
    () => true,
    () => false,
  );
  const [tab, setTab] = useState<TabId>("dashboard");

  const [tasks, setTasks] = useState<Task[]>([]);
  const [habits, setHabits] = useState<Habit[]>([]);
  const [goals, setGoals] = useState<Goal[]>([]);
  const [stats, setStats] = useState<Stats | null>(null);
  const [blocksByDate, setBlocksByDate] = useState<Record<string, ScheduleBlock[]>>({});
  const [selectedDate, setSelectedDate] = useState<string>(() => todayISO());

  const handleError = useCallback((e: unknown, fallback: string) => {
    toast.error(e instanceof Error ? e.message : fallback);
  }, []);

  const fetchTasks = useCallback(async () => {
    try {
      const d = await api<{ tasks: Task[] }>("/api/tasks");
      setTasks(d.tasks);
    } catch (e) {
      handleError(e, "دریافت وظایف ناموفق بود");
    }
  }, [handleError]);

  const fetchHabits = useCallback(async () => {
    try {
      const d = await api<{ habits: Habit[] }>("/api/habits");
      setHabits(d.habits);
    } catch (e) {
      handleError(e, "دریافت عادت‌ها ناموفق بود");
    }
  }, [handleError]);

  const fetchGoals = useCallback(async () => {
    try {
      const d = await api<{ goals: Goal[] }>("/api/goals");
      setGoals(d.goals);
    } catch (e) {
      handleError(e, "دریافت اهداف ناموفق بود");
    }
  }, [handleError]);

  const fetchStats = useCallback(async () => {
    try {
      const d = await api<Stats>("/api/stats");
      setStats(d);
    } catch (e) {
      handleError(e, "دریافت آمار ناموفق بود");
    }
  }, [handleError]);

  const fetchBlocks = useCallback(
    async (date: string) => {
      try {
        const d = await api<{ blocks: ScheduleBlock[] }>(`/api/schedule?date=${date}`);
        setBlocksByDate((prev) => ({ ...prev, [date]: d.blocks }));
      } catch (e) {
        handleError(e, "دریافت برنامه روز ناموفق بود");
      }
    },
    [handleError],
  );

  // initial load (state updates happen after await → async, lint-safe)
  useEffect(() => {
    if (!mounted) return;
    let cancelled = false;
    void (async () => {
      const [t, h, g, s] = await Promise.all([
        api<{ tasks: Task[] }>("/api/tasks").catch(() => null),
        api<{ habits: Habit[] }>("/api/habits").catch(() => null),
        api<{ goals: Goal[] }>("/api/goals").catch(() => null),
        api<Stats>("/api/stats").catch(() => null),
      ]);
      if (cancelled) return;
      if (t) setTasks(t.tasks);
      else toast.error("دریافت وظایف ناموفق بود");
      if (h) setHabits(h.habits);
      else toast.error("دریافت عادت‌ها ناموفق بود");
      if (g) setGoals(g.goals);
      else toast.error("دریافت اهداف ناموفق بود");
      if (s) setStats(s);
      else toast.error("دریافت آمار ناموفق بود");
    })();
    return () => {
      cancelled = true;
    };
  }, [mounted]);

  // load schedule blocks whenever the selected day changes
  useEffect(() => {
    if (!mounted) return;
    let cancelled = false;
    void (async () => {
      try {
        const d = await api<{ blocks: ScheduleBlock[] }>(`/api/schedule?date=${selectedDate}`);
        if (!cancelled) {
          setBlocksByDate((prev) => ({ ...prev, [selectedDate]: d.blocks }));
        }
      } catch (e) {
        if (!cancelled) handleError(e, "دریافت برنامه روز ناموفق بود");
      }
    })();
    return () => {
      cancelled = true;
    };
  }, [mounted, selectedDate, handleError]);

  /* ------------------------------- task actions ------------------------------- */

  const addTask = useCallback(
    async (input: NewTaskInput) => {
      try {
        await api<{ task: Task }>("/api/tasks", { method: "POST", body: JSON.stringify(input) });
        toast.success("وظیفه اضافه شد 🌱");
        fetchTasks();
        fetchStats();
        return true;
      } catch (e) {
        handleError(e, "افزودن وظیفه ناموفق بود");
        return false;
      }
    },
    [fetchTasks, fetchStats, handleError],
  );

  const toggleTask = useCallback(
    (task: Task) => {
      setTasks((prev) =>
        prev.map((t) => (t.id === task.id ? { ...t, completed: !t.completed } : t)),
      );
      api<{ task: Task }>(`/api/tasks/${task.id}`, {
        method: "PATCH",
        body: JSON.stringify({ completed: !task.completed }),
      })
        .then(() => fetchStats())
        .catch((e) => {
          setTasks((prev) =>
            prev.map((t) => (t.id === task.id ? { ...t, completed: task.completed } : t)),
          );
          handleError(e, "تغییر وضعیت وظیفه ناموفق بود");
        });
    },
    [fetchStats, handleError],
  );

  const deleteTask = useCallback(
    (id: string) => {
      const prevTasks = tasks;
      setTasks((prev) => prev.filter((t) => t.id !== id));
      api(`/api/tasks/${id}`, { method: "DELETE" })
        .then(() => {
          toast.success("وظیفه حذف شد");
          fetchStats();
        })
        .catch((e) => {
          setTasks(prevTasks);
          handleError(e, "حذف وظیفه ناموفق بود");
        });
    },
    [tasks, fetchStats, handleError],
  );

  /* ------------------------------ schedule actions ----------------------------- */

  const addBlock = useCallback(
    async (input: NewBlockInput) => {
      try {
        await api<{ block: ScheduleBlock }>("/api/schedule", {
          method: "POST",
          body: JSON.stringify(input),
        });
        toast.success("به برنامه روز اضافه شد 🗓");
        fetchBlocks(input.date);
        fetchStats();
        return true;
      } catch (e) {
        handleError(e, "افزودن به برنامه ناموفق بود");
        return false;
      }
    },
    [fetchBlocks, fetchStats, handleError],
  );

  const toggleBlock = useCallback(
    (block: ScheduleBlock) => {
      setBlocksByDate((prev) => ({
        ...prev,
        [block.date]: (prev[block.date] ?? []).map((b) =>
          b.id === block.id ? { ...b, completed: !b.completed } : b,
        ),
      }));
      api<{ block: ScheduleBlock }>(`/api/schedule/${block.id}`, {
        method: "PATCH",
        body: JSON.stringify({ completed: !block.completed }),
      }).catch((e) => {
        fetchBlocks(block.date);
        handleError(e, "تغییر وضعیت برنامه ناموفق بود");
      });
    },
    [fetchBlocks, handleError],
  );

  const deleteBlock = useCallback(
    (id: string) => {
      const date = selectedDate;
      setBlocksByDate((prev) => ({
        ...prev,
        [date]: (prev[date] ?? []).filter((b) => b.id !== id),
      }));
      api(`/api/schedule/${id}`, { method: "DELETE" })
        .then(() => toast.success("از برنامه حذف شد"))
        .catch((e) => {
          fetchBlocks(date);
          handleError(e, "حذف از برنامه ناموفق بود");
        });
    },
    [selectedDate, fetchBlocks, handleError],
  );

  /* ------------------------------- habit actions ------------------------------- */

  const addHabit = useCallback(
    async (input: { title: string; icon: string; targetDays: number }) => {
      try {
        await api<{ habit: Habit }>("/api/habits", {
          method: "POST",
          body: JSON.stringify(input),
        });
        toast.success("عادت جدید اضافه شد 🌱");
        fetchHabits();
        fetchStats();
        return true;
      } catch (e) {
        handleError(e, "افزودن عادت ناموفق بود");
        return false;
      }
    },
    [fetchHabits, fetchStats, handleError],
  );

  const toggleHabit = useCallback(
    (habitId: string, date: string) => {
      setHabits((prev) =>
        prev.map((h) => {
          if (h.id !== habitId) return h;
          const has = h.logs.some((l) => l.date === date);
          return {
            ...h,
            logs: has
              ? h.logs.filter((l) => l.date !== date)
              : [...h.logs, { id: `tmp-${habitId}-${date}`, habitId, date, createdAt: "" }],
          };
        }),
      );
      api<{ habit: Habit }>(`/api/habits/${habitId}/toggle`, {
        method: "POST",
        body: JSON.stringify({ date }),
      })
        .then(() => fetchStats())
        .catch((e) => {
          fetchHabits();
          handleError(e, "ثبت عادت ناموفق بود");
        });
    },
    [fetchStats, fetchHabits, handleError],
  );

  const deleteHabit = useCallback(
    (id: string) => {
      const prevHabits = habits;
      setHabits((prev) => prev.filter((h) => h.id !== id));
      api(`/api/habits/${id}`, { method: "DELETE" })
        .then(() => {
          toast.success("عادت حذف شد");
          fetchStats();
        })
        .catch((e) => {
          setHabits(prevHabits);
          handleError(e, "حذف عادت ناموفق بود");
        });
    },
    [habits, fetchStats, handleError],
  );

  /* ------------------------------- goal actions ------------------------------- */

  const addGoal = useCallback(
    async (input: { title: string; target: number; unit: string }) => {
      try {
        await api<{ goal: Goal }>("/api/goals", {
          method: "POST",
          body: JSON.stringify(input),
        });
        toast.success("هدف هفتگی اضافه شد 🎯");
        fetchGoals();
        fetchStats();
        return true;
      } catch (e) {
        handleError(e, "افزودن هدف ناموفق بود");
        return false;
      }
    },
    [fetchGoals, fetchStats, handleError],
  );

  const changeGoalProgress = useCallback(
    (goal: Goal, delta: number) => {
      const next = Math.max(0, Math.min(goal.target, goal.progress + delta));
      if (next === goal.progress) return;
      setGoals((prev) =>
        prev.map((g) => (g.id === goal.id ? { ...g, progress: next } : g)),
      );
      api<{ goal: Goal }>(`/api/goals/${goal.id}`, {
        method: "PATCH",
        body: JSON.stringify({ progress: next }),
      })
        .then(() => {
          if (next >= goal.target && goal.progress < goal.target) {
            toast.success("آفرین! هدف تکمیل شد 🎉");
          }
          fetchStats();
        })
        .catch((e) => {
          setGoals((prev) =>
            prev.map((g) => (g.id === goal.id ? { ...g, progress: goal.progress } : g)),
          );
          handleError(e, "ثبت پیشرفت ناموفق بود");
        });
    },
    [fetchStats, handleError],
  );

  const deleteGoal = useCallback(
    (id: string) => {
      const prevGoals = goals;
      setGoals((prev) => prev.filter((g) => g.id !== id));
      api(`/api/goals/${id}`, { method: "DELETE" })
        .then(() => {
          toast.success("هدف حذف شد");
          fetchStats();
        })
        .catch((e) => {
          setGoals(prevGoals);
          handleError(e, "حذف هدف ناموفق بود");
        });
    },
    [goals, fetchStats, handleError],
  );

  /* ---------------------------------- render ---------------------------------- */

  if (!mounted) {
    return <SplashScreen />;
  }

  const today = todayISO();
  const actions: AppActions = {
    addTask,
    toggleTask,
    deleteTask,
    addBlock,
    toggleBlock,
    deleteBlock,
    setSelectedDate: (iso: string) => {
      setSelectedDate(iso);
      setTab("schedule");
    },
    addHabit,
    toggleHabit,
    deleteHabit,
    addGoal,
    changeGoalProgress,
    deleteGoal,
  };

  const viewProps: ViewProps = {
    today,
    tasks,
    habits,
    goals,
    stats,
    blocksByDate,
    selectedDate,
    actions,
    navigate: setTab,
  };

  return (
    <div className="flex min-h-screen flex-col">
      <AppHeader today={today} />
      <MainNav tab={tab} onChange={setTab} />
      <main className="mx-auto w-full max-w-5xl flex-1 px-3 pb-12 pt-5 sm:px-6">
        <div key={tab}>
          {tab === "dashboard" && <DashboardView {...viewProps} />}
          {tab === "schedule" && <ScheduleView {...viewProps} />}
          {tab === "tasks" && <TasksView {...viewProps} />}
          {tab === "habits" && <HabitsView {...viewProps} />}
          {tab === "goals" && <GoalsView {...viewProps} />}
          {tab === "progress" && <ProgressView {...viewProps} />}
        </div>
      </main>
      <AppFooter />
    </div>
  );
}

/* ---------------------------------- pieces ---------------------------------- */

function SplashScreen() {
  return (
    <div className="flex min-h-screen flex-col items-center justify-center gap-3 bg-background">
      <div className="flex size-16 animate-pulse items-center justify-center rounded-2xl bg-primary text-primary-foreground">
        <Footprints className="size-8" aria-hidden />
      </div>
      <p className="text-lg font-extrabold">قدم به قدم</p>
      <p className="text-sm text-muted-foreground">در حال آماده‌سازی برنامه تو…</p>
    </div>
  );
}

function AppHeader({ today }: { today: string }) {
  const { theme, setTheme } = useTheme();
  const isDark = theme === "dark";

  return (
    <header className="sticky top-0 z-40 border-b bg-background/85 backdrop-blur">
      <div className="mx-auto flex h-16 w-full max-w-5xl items-center justify-between gap-3 px-3 sm:px-6">
        <div className="flex items-center gap-2.5">
          <div className="flex size-10 items-center justify-center rounded-xl bg-primary text-primary-foreground shadow-sm">
            <Footprints className="size-5" aria-hidden />
          </div>
          <div className="leading-tight">
            <h1 className="text-lg font-extrabold">قدم به قدم</h1>
            <p className="hidden text-xs text-muted-foreground sm:block">
              هر روز، یک قدم به جلو
            </p>
          </div>
          <span className="mr-2 hidden rounded-full bg-secondary px-3 py-1 text-xs font-medium text-secondary-foreground md:inline-block">
            امروز: {formatJalali(today, { weekday: "long", day: "numeric", month: "long" })}
          </span>
        </div>
        <Button
          variant="outline"
          size="icon"
          aria-label={isDark ? "حالت روشن" : "حالت تاریک"}
          onClick={() => setTheme(isDark ? "light" : "dark")}
          className="rounded-full"
        >
          {isDark ? <Sun className="size-4" /> : <Moon className="size-4" />}
        </Button>
      </div>
    </header>
  );
}

function MainNav({ tab, onChange }: { tab: TabId; onChange: (t: TabId) => void }) {
  return (
    <nav
      aria-label="بخش‌های اصلی"
      className="sticky top-16 z-30 border-b bg-background/85 backdrop-blur"
    >
      <div className="mx-auto w-full max-w-5xl px-3 sm:px-6">
        <div
          className="scrollbar-thin flex items-center gap-1.5 overflow-x-auto py-2.5"
          role="tablist"
        >
          {NAV_TABS.map((t) => {
            const Icon = TAB_ICONS[t.id];
            const active = tab === t.id;
            return (
              <button
                key={t.id}
                role="tab"
                aria-selected={active}
                onClick={() => onChange(t.id)}
                className={cn(
                  "flex shrink-0 items-center gap-1.5 rounded-full px-3.5 py-2 text-sm font-semibold transition-colors",
                  "min-h-[40px]",
                  active
                    ? "bg-primary text-primary-foreground shadow-sm"
                    : "text-muted-foreground hover:bg-accent hover:text-accent-foreground",
                )}
              >
                <Icon className="size-4" aria-hidden />
                {t.label}
              </button>
            );
          })}
        </div>
      </div>
    </nav>
  );
}

function AppFooter() {
  return (
    <footer className="mt-auto border-t bg-secondary/40 pb-[env(safe-area-inset-bottom)]">
      <div className="mx-auto flex w-full max-w-5xl flex-col items-center justify-between gap-1 px-4 py-4 text-center sm:flex-row sm:text-right">
        <p className="text-xs text-muted-foreground">
          <span className="font-bold text-foreground">قدم به قدم</span> — ابزار
          برنامه‌ریزی روزانه، مدیریت وظایف و ایجاد عادت‌های مفید
        </p>
        <p className="text-xs text-muted-foreground">
          هر روز یک قدم به جلو 🌱
        </p>
      </div>
    </footer>
  );
}
