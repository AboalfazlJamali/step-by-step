"use client";

import { CalendarDays, ListChecks, Sprout, Target, ChevronLeft } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Checkbox } from "@/components/ui/checkbox";
import { Progress } from "@/components/ui/progress";
import { SectionCard, EmptyState } from "./shared";
import type { ViewProps } from "../app";
import {
  categoryInfo,
  dueLabel,
  formatJalali,
  formatTimeFA,
  habitStreak,
  logsInWeek,
  pct,
  toFaDigits,
  DAY_NAMES_FA,
  fromISO,
  getPersianWeek,
  weekStartISO,
} from "@/lib/stepbystep";
import type { TabId } from "@/lib/stepbystep";
import { cn } from "@/lib/utils";

const MOTIVATIONS = [
  "یکشنبه‌ات پرانرژی! اولین قدم‌های هفته را بردار.",
  "دوشنبه خوبی داشته باشی! ادامه بده، تو به راهی.",
  "سه‌شنبه‌ات پربار! قدم‌های کوچک، پیروزی‌های بزرگ.",
  "چهارشنبه‌ات پر از پیشرفت! به تلاش‌هایت ادامه بده.",
  "پنجشنبه‌ات زیبا! آخر هفته نزدیک است، محکم بمان.",
  "جمعه‌ات آرام! کمی استراحت هم بخشی از برنامه است.",
  "شنبه‌ات مبارک! شروع تازه، فرصت تازه.",
];

export function DashboardView({ today, tasks, habits, goals, stats, blocksByDate, actions, navigate }: ViewProps) {
  const todayBlocks = blocksByDate[today] ?? [];
  const week = getPersianWeek(today);

  const openToday = tasks.filter((t) => !t.completed && t.dueDate && t.dueDate <= today);
  const doneTodayCount = stats?.taskCompleted ?? tasks.filter((t) => t.completed).length;
  const habitsDoneToday = habits.filter((h) => h.logs.some((l) => l.date === today)).length;
  const goalsAvg = goals.length
    ? Math.round(goals.reduce((s, g) => s + pct(g.progress, g.target), 0) / goals.length)
    : 0;
  const nextBlock = todayBlocks.find((b) => !b.completed);

  return (
    <div className="space-y-5">
      {/* Hero */}
      <section
        className="relative overflow-hidden rounded-2xl border bg-gradient-to-l from-primary/15 via-primary/8 to-transparent p-5 sm:p-7"
        aria-label="خوش‌آمدگویی"
      >
        <div className="pointer-events-none absolute -left-10 -top-10 size-40 rounded-full bg-primary/10 blur-2xl" aria-hidden />
        <div className="flex flex-col gap-4 sm:flex-row sm:items-center sm:justify-between">
          <div>
            <p className="text-sm font-medium text-muted-foreground">
              {formatJalali(today, { weekday: "long", day: "numeric", month: "long", year: "numeric" })}
            </p>
            <h2 className="mt-1 text-2xl font-extrabold sm:text-3xl">سلام! 👋</h2>
            <p className="mt-1 max-w-md text-sm text-muted-foreground">
              {MOTIVATIONS[fromISO(today).getDay()]}
            </p>
          </div>
          <div className="flex gap-2 sm:gap-3">
            <HeroStat label="وظایف باز" value={toFaDigits(openToday.length)} hint="برای امروز" onClick={() => navigate("tasks")} />
            <HeroStat
              label="عادت امروز"
              value={`${toFaDigits(habitsDoneToday)}/${toFaDigits(habits.length)}`}
              hint="انجام شده"
              onClick={() => navigate("habits")}
            />
            <HeroStat label="اهداف هفته" value={`${toFaDigits(goalsAvg)}٪`} hint="میانگین پیشرفت" onClick={() => navigate("goals")} />
          </div>
        </div>
      </section>

      <div className="grid gap-5 lg:grid-cols-2">
        {/* Today tasks */}
        <SectionCard
          icon={ListChecks}
          title="وظایف امروز"
          action={<NavChip label="همه وظایف" onClick={() => navigate("tasks")} />}
        >
          {openToday.length === 0 ? (
            <EmptyState emoji="✅" title="همه وظایف امروز انجام شده!" hint="یک وظیفه جدید اضافه کن و قدم بعدی را بردار." />
          ) : (
            <ul className="space-y-1.5">
              {openToday.slice(0, 5).map((t) => {
                const cat = categoryInfo(t.category);
                const due = t.dueDate ? dueLabel(t.dueDate) : null;
                return (
                  <li
                    key={t.id}
                    className="flex items-center gap-2.5 rounded-lg px-2 py-2 transition-colors hover:bg-accent/60"
                  >
                    <Checkbox
                      checked={false}
                      onCheckedChange={() => actions.toggleTask(t)}
                      aria-label={`انجام وظیفه ${t.title}`}
                      className="size-5"
                    />
                    <span className="flex-1 truncate text-sm font-medium">{t.title}</span>
                    <Badge variant="outline" className={cn("shrink-0 gap-1 border-transparent", cat.badge)}>
                      {cat.emoji} {cat.label}
                    </Badge>
                    {due ? (
                      <Badge
                        variant="outline"
                        className={cn(
                          "shrink-0",
                          due.tone === "over" && "border-red-300 text-red-600 dark:text-red-400",
                          due.tone === "today" && "border-primary/40 text-primary",
                        )}
                      >
                        {due.text}
                      </Badge>
                    ) : null}
                  </li>
                );
              })}
              {openToday.length > 5 ? (
                <li className="pt-1 text-center">
                  <NavChip label={`و ${toFaDigits(openToday.length - 5)} وظیفه دیگر`} onClick={() => navigate("tasks")} center />
                </li>
              ) : null}
            </ul>
          )}
        </SectionCard>

        {/* Today schedule */}
        <SectionCard
          icon={CalendarDays}
          title="برنامه امروز"
          action={<NavChip label="برنامه روزانه" onClick={() => navigate("schedule")} />}
        >
          {todayBlocks.length === 0 ? (
            <EmptyState emoji="🗓️" title="برنامه‌ای برای امروز ثبت نشده" hint="از بخش «برنامه روزانه» زمان‌های مطالعه، ورزش و استراحت را بچین." />
          ) : (
            <ul className="space-y-1.5">
              {todayBlocks.slice(0, 5).map((b) => {
                const cat = categoryInfo(b.category);
                return (
                  <li
                    key={b.id}
                    className="flex items-center gap-2.5 rounded-lg px-2 py-2 transition-colors hover:bg-accent/60"
                  >
                    <span className="flex shrink-0 items-center gap-1.5 rounded-md bg-secondary px-2 py-1 text-xs font-bold tabular-nums">
                      <span className={cn("size-1.5 rounded-full", cat.dot)} aria-hidden />
                      {formatTimeFA(b.startTime)}–{formatTimeFA(b.endTime)}
                    </span>
                    <span className={cn("flex-1 truncate text-sm font-medium", b.completed && "text-muted-foreground line-through")}>
                      {b.title}
                    </span>
                    {b.completed ? (
                      <Badge className="shrink-0 bg-primary/15 text-primary">انجام شد ✓</Badge>
                    ) : nextBlock?.id === b.id ? (
                      <Badge className="shrink-0 bg-amber-100 text-amber-800 dark:bg-amber-950 dark:text-amber-300">بعدی</Badge>
                    ) : null}
                  </li>
                );
              })}
              {todayBlocks.length > 5 ? (
                <li className="pt-1 text-center">
                  <NavChip label={`و ${toFaDigits(todayBlocks.length - 5)} فعالیت دیگر`} onClick={() => navigate("schedule")} center />
                </li>
              ) : null}
            </ul>
          )}
        </SectionCard>

        {/* Today habits */}
        <SectionCard
          icon={Sprout}
          title="عادت‌های امروز"
          action={<NavChip label="همه عادت‌ها" onClick={() => navigate("habits")} />}
        >
          {habits.length === 0 ? (
            <EmptyState emoji="🌱" title="هنوز عادتی نساخته‌ای" hint="یک عادت کوچک بساز؛ مثلاً «۲۰ صفحه کتاب‌خوانی» و هر روز تیکش را بزن." />
          ) : (
            <ul className="space-y-1.5">
              {habits.map((h) => {
                const done = h.logs.some((l) => l.date === today);
                const streak = habitStreak(h.logs);
                const weekDone = logsInWeek(h.logs, today);
                return (
                  <li key={h.id} className="flex items-center gap-2.5 rounded-lg px-2 py-2 transition-colors hover:bg-accent/60">
                    <button
                      onClick={() => actions.toggleHabit(h.id, today)}
                      aria-pressed={done}
                      aria-label={`ثبت عادت ${h.title} برای امروز`}
                      className={cn(
                        "flex size-9 shrink-0 items-center justify-center rounded-xl border text-lg transition-all active:scale-95",
                        done
                          ? "border-primary bg-primary text-primary-foreground"
                          : "bg-card hover:border-primary/50",
                      )}
                    >
                      {done ? "✓" : h.icon}
                    </button>
                    <span className={cn("flex-1 truncate text-sm font-medium", done && "text-muted-foreground")}>
                      {h.title}
                    </span>
                    {streak > 0 ? (
                      <Badge variant="outline" className="shrink-0 border-orange-300 text-orange-600 dark:text-orange-400">
                        🔥 {toFaDigits(streak)} روز
                      </Badge>
                    ) : null}
                    <span className="shrink-0 text-xs text-muted-foreground tabular-nums">
                      {toFaDigits(weekDone)}/{toFaDigits(h.targetDays)}
                    </span>
                  </li>
                );
              })}
            </ul>
          )}
        </SectionCard>

        {/* Weekly goals */}
        <SectionCard
          icon={Target}
          title="اهداف این هفته"
          action={<NavChip label="همه اهداف" onClick={() => navigate("goals")} />}
        >
          {goals.length === 0 ? (
            <EmptyState emoji="🎯" title="هدفی برای این هفته نداری" hint="یک هدف کوچک و روشن تعیین کن؛ مثلاً «۴ جلسه ورزش در هفته»." />
          ) : (
            <ul className="space-y-3.5">
              {goals.slice(0, 4).map((g) => {
                const p = pct(g.progress, g.target);
                const done = g.progress >= g.target;
                return (
                  <li key={g.id} className="space-y-1.5">
                    <div className="flex items-center justify-between gap-2">
                      <span className="truncate text-sm font-medium">
                        {done && <span aria-hidden>🎉 </span>}
                        {g.title}
                      </span>
                      <span className="shrink-0 text-xs font-bold tabular-nums text-primary">
                        {toFaDigits(g.progress)}/{toFaDigits(g.target)} {g.unit}
                      </span>
                    </div>
                    <Progress value={p} aria-label={`پیشرفت ${g.title}`} className="h-2" />
                  </li>
                );
              })}
            </ul>
          )}
        </SectionCard>
      </div>

      {/* Week strip */}
      <section aria-label="روزهای هفته" className="rounded-2xl border bg-card p-4">
        <div className="mb-3 flex items-center justify-between">
          <h3 className="text-sm font-bold">هفته جاری</h3>
          <span className="text-xs text-muted-foreground">
            {formatJalali(weekStartISO(today), { day: "numeric", month: "long" })} تا{" "}
            {formatJalali(week[6], { day: "numeric", month: "long" })}
          </span>
        </div>
        <div className="grid grid-cols-7 gap-1.5 sm:gap-2">
          {week.map((d) => {
            const isToday = d === today;
            const isPast = d < today;
            const dayTasks = tasks.filter((t) => t.dueDate === d && !t.completed).length;
            const dayBlocks = (blocksByDate[d] ?? []).length;
            return (
              <button
                key={d}
                onClick={() => actions.setSelectedDate(d)}
                className={cn(
                  "flex flex-col items-center gap-0.5 rounded-xl border py-2 transition-all hover:border-primary/50 active:scale-95",
                  isToday && "border-primary bg-primary/10",
                )}
                aria-label={`برنامه روز ${DAY_NAMES_FA[fromISO(d).getDay()]}`}
              >
                <span className={cn("text-[11px]", isToday ? "font-bold text-primary" : "text-muted-foreground")}>
                  {DAY_NAMES_FA[fromISO(d).getDay()]}
                </span>
                <span className={cn("text-sm font-extrabold tabular-nums", isPast && "text-muted-foreground")}>
                  {formatJalali(d, { day: "numeric" })}
                </span>
                <span className="flex gap-0.5" aria-hidden>
                  {dayTasks > 0 && <span className="size-1.5 rounded-full bg-amber-500" />}
                  {dayBlocks > 0 && <span className="size-1.5 rounded-full bg-primary" />}
                </span>
              </button>
            );
          })}
        </div>
      </section>
    </div>
  );
}

function HeroStat({
  label,
  value,
  hint,
  onClick,
}: {
  label: string;
  value: string;
  hint: string;
  onClick: () => void;
}) {
  return (
    <button
      onClick={onClick}
      className="min-w-[92px] rounded-xl border bg-card/80 p-3 text-center backdrop-blur transition-all hover:border-primary/50 hover:shadow-sm active:scale-95"
    >
      <p className="text-[11px] text-muted-foreground">{label}</p>
      <p className="text-xl font-extrabold tabular-nums">{value}</p>
      <p className="text-[10px] text-muted-foreground">{hint}</p>
    </button>
  );
}

function NavChip({ label, onClick, center }: { label: string; onClick: () => void; center?: boolean }) {
  return (
    <Button
      variant="ghost"
      size="sm"
      onClick={onClick}
      className={cn("h-8 gap-1 text-xs font-semibold text-primary hover:text-primary", center && "w-full justify-center")}
    >
      {label}
      <ChevronLeft className="size-3.5" aria-hidden />
    </Button>
  );
}
