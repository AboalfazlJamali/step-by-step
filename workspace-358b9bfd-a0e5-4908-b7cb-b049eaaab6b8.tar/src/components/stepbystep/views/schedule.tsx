"use client";

import { useState } from "react";
import { CalendarDays, ChevronLeft, ChevronRight, Clock, Plus, Trash2 } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Input } from "@/components/ui/input";
import { Checkbox } from "@/components/ui/checkbox";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { SectionCard, EmptyState } from "./shared";
import type { ViewProps } from "../app";
import {
  CATEGORY_LIST,
  CATEGORIES,
  DAY_NAMES_FA,
  addDaysISO,
  categoryInfo,
  formatDuration,
  formatJalali,
  formatTimeFA,
  fromISO,
  toFaDigits,
  todayISO,
} from "@/lib/stepbystep";
import type { Category } from "@/lib/stepbystep";
import { cn } from "@/lib/utils";

const TIME_PRESETS = ["06:00", "08:00", "10:00", "14:00", "17:00", "19:00", "21:00"];

export function ScheduleView({ today, selectedDate, blocksByDate, actions }: ViewProps) {
  const blocks = blocksByDate[selectedDate] ?? [];
  const isToday = selectedDate === today;

  const [title, setTitle] = useState("");
  const [startTime, setStartTime] = useState("08:00");
  const [endTime, setEndTime] = useState("09:30");
  const [category, setCategory] = useState<Category>("study");
  const [note, setNote] = useState("");
  const [submitting, setSubmitting] = useState(false);

  async function submit() {
    const trimmed = title.trim();
    if (!trimmed) return;
    setSubmitting(true);
    const ok = await actions.addBlock({
      date: selectedDate,
      startTime,
      endTime,
      title: trimmed,
      category,
      note: note.trim() || undefined,
    });
    setSubmitting(false);
    if (ok) {
      setTitle("");
      setNote("");
    }
  }

  const totalMinutes = blocks.reduce((s, b) => {
    const [sh, sm] = b.startTime.split(":").map(Number);
    const [eh, em] = b.endTime.split(":").map(Number);
    const m = eh * 60 + em - (sh * 60 + sm);
    return s + (m > 0 ? m : 0);
  }, 0);
  const doneCount = blocks.filter((b) => b.completed).length;

  return (
    <div className="space-y-5">
      {/* Date navigation */}
      <section className="rounded-2xl border bg-card p-4" aria-label="انتخاب روز">
        <div className="flex items-center justify-between gap-2">
          <Button
            variant="outline"
            size="icon"
            onClick={() => actions.setSelectedDate(addDaysISO(selectedDate, 1))}
            aria-label="روز بعد"
            className="rounded-full"
          >
            <ChevronLeft className="size-4" aria-hidden />
          </Button>
          <div className="text-center">
            <p className="text-lg font-extrabold">
              {formatJalali(selectedDate, { weekday: "long", day: "numeric", month: "long", year: "numeric" })}
            </p>
            <div className="mt-1 flex items-center justify-center gap-2">
              <Badge variant="outline" className="text-muted-foreground">
                {DAY_NAMES_FA[fromISO(selectedDate).getDay()]}
              </Badge>
              {!isToday ? (
                <Button
                  variant="ghost"
                  size="sm"
                  onClick={() => actions.setSelectedDate(todayISO())}
                  className="h-7 gap-1 text-xs text-primary hover:text-primary"
                >
                  بازگشت به امروز
                </Button>
              ) : (
                <Badge className="bg-primary/15 text-primary">امروز</Badge>
              )}
            </div>
          </div>
          <Button
            variant="outline"
            size="icon"
            onClick={() => actions.setSelectedDate(addDaysISO(selectedDate, -1))}
            aria-label="روز قبل"
            className="rounded-full"
          >
            <ChevronRight className="size-4" aria-hidden />
          </Button>
        </div>
      </section>

      {/* Add form */}
      <SectionCard icon={Plus} title="افزودن فعالیت">
        <form
          onSubmit={(e) => {
            e.preventDefault();
            submit();
          }}
          className="space-y-3"
        >
          <Input
            value={title}
            onChange={(e) => setTitle(e.target.value)}
            placeholder="مثلاً: مطالعه فیزیک — فصل نیروها"
            aria-label="عنوان فعالیت"
            maxLength={200}
            className="h-11"
          />
          <div className="grid grid-cols-2 gap-3 sm:grid-cols-4">
            <label className="block space-y-1">
              <span className="text-xs font-medium text-muted-foreground">از ساعت</span>
              <Input
                type="time"
                value={startTime}
                onChange={(e) => setStartTime(e.target.value)}
                aria-label="ساعت شروع"
                className="h-10"
              />
            </label>
            <label className="block space-y-1">
              <span className="text-xs font-medium text-muted-foreground">تا ساعت</span>
              <Input
                type="time"
                value={endTime}
                onChange={(e) => setEndTime(e.target.value)}
                aria-label="ساعت پایان"
                className="h-10"
              />
            </label>
            <label className="block space-y-1">
              <span className="text-xs font-medium text-muted-foreground">دسته‌بندی</span>
              <Select value={category} onValueChange={(v) => setCategory(v as Category)}>
                <SelectTrigger aria-label="دسته‌بندی فعالیت" className="h-10 w-full">
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  {CATEGORY_LIST.map((c) => (
                    <SelectItem key={c} value={c}>
                      {CATEGORIES[c].emoji} {CATEGORIES[c].label}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </label>
            <label className="block space-y-1">
              <span className="text-xs font-medium text-muted-foreground">یادداشت (اختیاری)</span>
              <Input
                value={note}
                onChange={(e) => setNote(e.target.value)}
                placeholder="مثلاً: صفحات ۴۰ تا ۶۰"
                aria-label="یادداشت"
                className="h-10"
                maxLength={200}
              />
            </label>
          </div>
          <div className="flex flex-wrap items-center gap-1.5">
            <span className="text-xs text-muted-foreground">ساعت‌های پرکاربرد:</span>
            {TIME_PRESETS.map((t) => (
              <button
                key={t}
                type="button"
                onClick={() => {
                  const [h, m] = t.split(":").map(Number);
                  const endH = h + 1;
                  setStartTime(t);
                  setEndTime(`${String(endH).padStart(2, "0")}:${String(m).padStart(2, "0")}`);
                }}
                className="rounded-full border px-2.5 py-1 text-xs font-semibold tabular-nums text-muted-foreground transition-colors hover:bg-accent min-h-[28px]"
              >
                {toFaDigits(t)}
              </button>
            ))}
          </div>
          <Button
            type="submit"
            disabled={!title.trim() || !startTime || !endTime || submitting}
            className="h-11 w-full gap-1.5 sm:w-auto"
          >
            <Plus className="size-4" aria-hidden />
            افزودن به برنامه
          </Button>
        </form>
      </SectionCard>

      {/* Timeline */}
      <SectionCard
        icon={CalendarDays}
        title={isToday ? "برنامه امروز" : "برنامه این روز"}
        contentClassName="space-y-2"
      >
        <div className="flex items-center gap-3 pb-1 text-xs text-muted-foreground">
          <span className="flex items-center gap-1">
            <Clock className="size-3.5" aria-hidden />
            {toFaDigits(blocks.length)} فعالیت
          </span>
          <span>•</span>
          <span>
            مجموع:{" "}
            {totalMinutes >= 60
              ? `${toFaDigits(Math.floor(totalMinutes / 60))} ساعت${totalMinutes % 60 ? ` و ${toFaDigits(totalMinutes % 60)} دقیقه` : ""}`
              : `${toFaDigits(totalMinutes)} دقیقه`}
          </span>
          <span>•</span>
          <span className="tabular-nums">
            {toFaDigits(doneCount)}/{toFaDigits(blocks.length)} انجام شده
          </span>
        </div>

        {blocks.length === 0 ? (
          <EmptyState
            emoji="🗓️"
            title="برنامه‌ای برای این روز ثبت نشده"
            hint="زمان مطالعه، تکالیف، ورزش و استراحت را همین‌جا بچین تا روزت منظم شود."
          />
        ) : (
          <ul className="space-y-2" aria-label="برنامه روز">
            {blocks.map((b) => {
              const cat = categoryInfo(b.category);
              return (
                <li
                  key={b.id}
                  className={cn(
                    "flex items-stretch overflow-hidden rounded-xl border bg-card transition-all hover:shadow-sm",
                    b.completed && "opacity-60",
                  )}
                >
                  {/* time column */}
                  <div className={cn("flex w-20 shrink-0 flex-col items-center justify-center gap-0.5 p-2 text-center", cat.soft)}>
                    <span className="text-sm font-extrabold tabular-nums">{formatTimeFA(b.startTime)}</span>
                    <span className="text-[11px] text-muted-foreground tabular-nums">{formatTimeFA(b.endTime)}</span>
                    <span className="text-[10px] text-muted-foreground">{formatDuration(b.startTime, b.endTime)}</span>
                  </div>
                  {/* body */}
                  <div className="flex min-w-0 flex-1 items-center gap-3 px-3 py-2.5">
                    <Checkbox
                      checked={b.completed}
                      onCheckedChange={() => actions.toggleBlock(b)}
                      aria-label={b.completed ? `لغو انجام ${b.title}` : `انجام ${b.title}`}
                      className="size-5 shrink-0"
                    />
                    <div className="min-w-0 flex-1">
                      <p className={cn("truncate text-sm font-semibold", b.completed && "line-through")}>
                        <span className="mr-1" aria-hidden>{cat.emoji}</span>
                        {b.title}
                      </p>
                      {b.note ? <p className="truncate text-xs text-muted-foreground">📝 {b.note}</p> : null}
                      <Badge variant="outline" className={cn("mt-1 gap-1 border-transparent", cat.badge)}>
                        {cat.label}
                      </Badge>
                    </div>
                    <Button
                      variant="ghost"
                      size="icon"
                      onClick={() => actions.deleteBlock(b.id)}
                      aria-label={`حذف ${b.title} از برنامه`}
                      className="size-8 shrink-0 text-muted-foreground hover:text-destructive"
                    >
                      <Trash2 className="size-4" aria-hidden />
                    </Button>
                  </div>
                </li>
              );
            })}
          </ul>
        )}
      </SectionCard>
    </div>
  );
}
