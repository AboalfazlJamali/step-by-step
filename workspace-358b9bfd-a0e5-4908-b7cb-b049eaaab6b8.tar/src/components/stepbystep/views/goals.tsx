"use client";

import { useState } from "react";
import { Target, Plus, Minus, Trash2 } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Input } from "@/components/ui/input";
import { Progress } from "@/components/ui/progress";
import { SectionCard, EmptyState } from "./shared";
import type { ViewProps } from "../app";
import { GOAL_UNITS, formatJalali, getPersianWeek, pct, toFaDigits } from "@/lib/stepbystep";
import type { Goal } from "@/lib/stepbystep";
import { cn } from "@/lib/utils";

export function GoalsView({ today, goals, actions }: ViewProps) {
  const [title, setTitle] = useState("");
  const [target, setTarget] = useState("5");
  const [unit, setUnit] = useState(GOAL_UNITS[0]);
  const [submitting, setSubmitting] = useState(false);

  const week = getPersianWeek(today);
  const doneGoals = goals.filter((g) => g.progress >= g.target).length;

  async function submit() {
    const trimmed = title.trim();
    const n = parseInt(target, 10);
    if (!trimmed || !Number.isFinite(n) || n < 1) return;
    setSubmitting(true);
    const ok = await actions.addGoal({
      title: trimmed,
      target: Math.min(10000, n),
      unit: unit.trim() || GOAL_UNITS[0],
    });
    setSubmitting(false);
    if (ok) {
      setTitle("");
      setTarget("5");
      setUnit(GOAL_UNITS[0]);
    }
  }

  return (
    <div className="space-y-5">
      {/* Week header */}
      <section className="rounded-2xl border bg-gradient-to-l from-primary/10 to-transparent p-5">
        <div className="flex flex-wrap items-center justify-between gap-3">
          <div>
            <h2 className="text-lg font-extrabold">🎯 اهداف هفتگی</h2>
            <p className="mt-0.5 text-sm text-muted-foreground">
              هفته {formatJalali(week[0], { day: "numeric", month: "long" })} تا{" "}
              {formatJalali(week[6], { day: "numeric", month: "long" })}
            </p>
          </div>
          <div className="flex items-center gap-2">
            <Badge variant="outline" className="tabular-nums">
              {toFaDigits(goals.length)} هدف
            </Badge>
            <Badge className="bg-primary/15 text-primary tabular-nums">
              {toFaDigits(doneGoals)} تکمیل شده
            </Badge>
          </div>
        </div>
        <p className="mt-2 text-xs text-muted-foreground">
          هر شنبه یک شروع تازه است — اهداف این هفته را همین‌جا تعیین کن و هر روز کمی به آن‌ها نزدیک‌تر شو.
        </p>
      </section>

      {/* Add goal */}
      <SectionCard icon={Plus} title="هدف جدید این هفته">
        <form
          onSubmit={(e) => {
            e.preventDefault();
            submit();
          }}
          className="space-y-3"
        >
          <Input
            value={title}
            onChange={(e) => setTitle(e.target.value)}
            placeholder="مثلاً: خواندن کتاب داستان"
            aria-label="عنوان هدف"
            maxLength={200}
            className="h-11"
          />
          <div className="grid gap-3 sm:grid-cols-3">
            <label className="block space-y-1">
              <span className="text-xs font-medium text-muted-foreground">مقدار هدف</span>
              <Input
                type="number"
                min={1}
                max={10000}
                value={target}
                onChange={(e) => setTarget(e.target.value)}
                aria-label="مقدار هدف"
                className="h-10"
                inputMode="numeric"
              />
            </label>
            <label className="block space-y-1 sm:col-span-2">
              <span className="text-xs font-medium text-muted-foreground">واحد</span>
              <Input
                value={unit}
                onChange={(e) => setUnit(e.target.value)}
                list="goal-units"
                aria-label="واحد هدف"
                className="h-10"
                maxLength={30}
                placeholder="مرتبه، ساعت، صفحه…"
              />
              <datalist id="goal-units">
                {GOAL_UNITS.map((u) => (
                  <option key={u} value={u} />
                ))}
              </datalist>
            </label>
          </div>
          <Button
            type="submit"
            disabled={!title.trim() || !Number.isFinite(parseInt(target, 10)) || parseInt(target, 10) < 1 || submitting}
            className="h-11 w-full gap-1.5 sm:w-auto"
          >
            <Target className="size-4" aria-hidden />
            تعیین هدف
          </Button>
        </form>
      </SectionCard>

      {/* Goals list */}
      {goals.length === 0 ? (
        <EmptyState
          emoji="🎯"
          title="هنوز هدفی برای این هفته تعیین نکردی"
          hint="اهداف کوچک و قابل اندازه‌گیری بهترین دوست پیشرفت هستند؛ مثلاً «۳ جلسه ورزش» یا «۵۰ صفحه مطالعه»."
        />
      ) : (
        <ul className="grid gap-4 sm:grid-cols-2" aria-label="فهرست اهداف هفتگی">
          {goals.map((g) => (
            <GoalCard
              key={g.id}
              goal={g}
              onDelete={actions.deleteGoal}
              onProgress={actions.changeGoalProgress}
            />
          ))}
        </ul>
      )}
    </div>
  );
}

function GoalCard({
  goal,
  onDelete,
  onProgress,
}: {
  goal: Goal;
  onDelete: (id: string) => void;
  onProgress: (goal: Goal, delta: number) => void;
}) {
  const p = pct(goal.progress, goal.target);
  const done = goal.progress >= goal.target;
  return (
      <li
        className={cn(
          "rounded-2xl border bg-card p-4 transition-all hover:shadow-sm",
          done && "border-primary/40 bg-primary/5",
        )}
      >
        <div className="flex items-start justify-between gap-2">
          <div className="min-w-0">
            <p className="truncate font-bold">
              {done && <span aria-hidden>🎉 </span>}
              {goal.title}
            </p>
            <p className="mt-0.5 text-xs text-muted-foreground">
              هدف: {toFaDigits(goal.target)} {goal.unit} در هفته
            </p>
          </div>
          <div className="flex shrink-0 items-center gap-1">
            <Button
              variant="ghost"
              size="icon"
              onClick={() => onDelete(goal.id)}
              aria-label={`حذف هدف ${goal.title}`}
              className="size-8 text-muted-foreground hover:text-destructive"
            >
              <Trash2 className="size-4" aria-hidden />
            </Button>
          </div>
        </div>

        <div className="mt-3 flex items-center gap-3">
          <Button
            variant="outline"
            size="icon"
            onClick={() => onProgress(goal, -1)}
            disabled={goal.progress <= 0}
            aria-label={`کاهش پیشرفت ${goal.title}`}
            className="size-9 shrink-0 rounded-full"
          >
            <Minus className="size-4" aria-hidden />
          </Button>
          <div className="flex-1 space-y-1">
            <Progress value={p} aria-label={`پیشرفت ${goal.title}: ${p} درصد`} className="h-2.5" />
            <div className="flex items-center justify-between text-xs">
              <span className="font-semibold tabular-nums text-primary">
                {toFaDigits(goal.progress)} از {toFaDigits(goal.target)} {goal.unit}
              </span>
              <span className="tabular-nums text-muted-foreground">{toFaDigits(p)}٪</span>
            </div>
          </div>
          <Button
            size="icon"
            onClick={() => onProgress(goal, 1)}
            disabled={goal.progress >= goal.target}
            aria-label={`افزایش پیشرفت ${goal.title}`}
            className="size-9 shrink-0 rounded-full"
          >
            <Plus className="size-4" aria-hidden />
          </Button>
        </div>

        {done ? (
          <Badge className="mt-3 w-full justify-center bg-primary/15 text-primary">
            ✅ این هدف تکمیل شد؛ آفرین!
          </Badge>
        ) : null}
      </li>
  );
}
