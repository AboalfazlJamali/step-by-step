"use client";

import { useMemo, useState } from "react";
import { ListChecks, Plus, Trash2 } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Checkbox } from "@/components/ui/checkbox";
import { Input } from "@/components/ui/input";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { SectionCard, EmptyState } from "./shared";
import type { ViewProps } from "../app";
import {
  CATEGORY_LIST,
  CATEGORIES,
  PRIORITIES,
  addDaysISO,
  categoryInfo,
  dueLabel,
  toFaDigits,
} from "@/lib/stepbystep";
import type { Category, Priority } from "@/lib/stepbystep";
import { cn } from "@/lib/utils";

type StatusFilter = "all" | "open" | "done";
type CatFilter = "all" | Category;

const DUE_CHIPS: { label: string; days: number | null }[] = [
  { label: "امروز", days: 0 },
  { label: "فردا", days: 1 },
  { label: "پس‌فردا", days: 2 },
  { label: "بدون مهلت", days: null },
];

export function TasksView({ today, tasks, actions }: ViewProps) {
  const [title, setTitle] = useState("");
  const [category, setCategory] = useState<Category>("study");
  const [priority, setPriority] = useState<Priority>("medium");
  const [due, setDue] = useState<number | null>(0);
  const [submitting, setSubmitting] = useState(false);

  const [statusFilter, setStatusFilter] = useState<StatusFilter>("all");
  const [catFilter, setCatFilter] = useState<CatFilter>("all");

  const filtered = useMemo(() => {
    return tasks.filter((t) => {
      if (statusFilter === "open" && t.completed) return false;
      if (statusFilter === "done" && !t.completed) return false;
      if (catFilter !== "all" && t.category !== catFilter) return false;
      return true;
    });
  }, [tasks, statusFilter, catFilter]);

  const openCount = tasks.filter((t) => !t.completed).length;
  const doneCount = tasks.length - openCount;
  const donePct = tasks.length ? Math.round((doneCount / tasks.length) * 100) : 0;

  async function submit() {
    const trimmed = title.trim();
    if (!trimmed) return;
    setSubmitting(true);
    const ok = await actions.addTask({
      title: trimmed,
      category,
      priority,
      dueDate: due === null ? null : addDaysISO(today, due),
    });
    setSubmitting(false);
    if (ok) {
      setTitle("");
      setCategory("study");
      setPriority("medium");
      setDue(0);
    }
  }

  return (
    <div className="space-y-5">
      {/* Add form */}
      <SectionCard icon={ListChecks} title="وظیفه جدید">
        <form
          onSubmit={(e) => {
            e.preventDefault();
            submit();
          }}
          className="space-y-3"
        >
          <Input
            value={title}
            onChange={(e) => setTitle(e.target.value)}
            placeholder="مثلاً: مرور فصل ۳ ریاضی برای امتحان…"
            aria-label="عنوان وظیفه"
            maxLength={200}
            className="h-11"
          />
          <div className="grid gap-3 sm:grid-cols-2">
            <div className="flex gap-3">
              <Select value={category} onValueChange={(v) => setCategory(v as Category)}>
                <SelectTrigger aria-label="دسته‌بندی" className="h-11 flex-1">
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  {CATEGORY_LIST.map((c) => (
                    <SelectItem key={c} value={c}>
                      {CATEGORIES[c].emoji} {CATEGORIES[c].label}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
              <Select value={priority} onValueChange={(v) => setPriority(v as Priority)}>
                <SelectTrigger aria-label="اولویت" className="h-11 flex-1">
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  {(Object.keys(PRIORITIES) as Priority[]).map((p) => (
                    <SelectItem key={p} value={p}>
                      اولویت {PRIORITIES[p].label}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>
            <div className="flex flex-wrap items-center gap-1.5">
              {DUE_CHIPS.map((chip) => (
                <button
                  key={chip.label}
                  type="button"
                  onClick={() => setDue(chip.days)}
                  aria-pressed={due === chip.days}
                  className={cn(
                    "rounded-full border px-3 py-1.5 text-xs font-semibold transition-colors min-h-[32px]",
                    due === chip.days
                      ? "border-primary bg-primary text-primary-foreground"
                      : "text-muted-foreground hover:bg-accent",
                  )}
                >
                  {chip.label}
                </button>
              ))}
            </div>
          </div>
          <Button type="submit" disabled={!title.trim() || submitting} className="h-11 w-full gap-1.5 sm:w-auto">
            <Plus className="size-4" aria-hidden />
            افزودن وظیفه
          </Button>
        </form>
      </SectionCard>

      {/* Summary + filters */}
      <div className="flex flex-col gap-3 rounded-2xl border bg-card p-4">
        <div className="flex items-center justify-between gap-3">
          <p className="text-sm font-semibold">
            <span className="tabular-nums text-primary">{toFaDigits(doneCount)}</span> از{" "}
            <span className="tabular-nums">{toFaDigits(tasks.length)}</span> وظیفه انجام شده
            <span className="mr-2 text-xs font-normal text-muted-foreground">({toFaDigits(donePct)}٪)</span>
          </p>
          <div className="flex gap-1.5">
            {(
              [
                { id: "all", label: "همه" },
                { id: "open", label: "انجام‌نشده" },
                { id: "done", label: "انجام‌شده" },
              ] as { id: StatusFilter; label: string }[]
            ).map((s) => (
              <button
                key={s.id}
                onClick={() => setStatusFilter(s.id)}
                aria-pressed={statusFilter === s.id}
                className={cn(
                  "rounded-full px-3 py-1.5 text-xs font-semibold transition-colors min-h-[32px]",
                  statusFilter === s.id
                    ? "bg-primary text-primary-foreground"
                    : "bg-secondary text-secondary-foreground hover:bg-accent",
                )}
              >
                {s.label}
              </button>
            ))}
          </div>
        </div>
        <div className="scrollbar-thin flex gap-1.5 overflow-x-auto pb-0.5">
          <CatChip active={catFilter === "all"} onClick={() => setCatFilter("all")} label="همه دسته‌ها" emoji="🗂" />
          {CATEGORY_LIST.map((c) => (
            <CatChip
              key={c}
              active={catFilter === c}
              onClick={() => setCatFilter(c)}
              label={CATEGORIES[c].label}
              emoji={CATEGORIES[c].emoji}
            />
          ))}
        </div>
      </div>

      {/* List */}
      {filtered.length === 0 ? (
        <EmptyState
          emoji="📋"
          title={tasks.length === 0 ? "هنوز وظیفه‌ای نداری" : "چیزی با این فیلتر پیدا نشد"}
          hint={tasks.length === 0 ? "اولین قدم را بردار و یک وظیفه کوچک اضافه کن!" : "فیلتر دیگری را امتحان کن."}
        />
      ) : (
        <ul className="space-y-2" aria-label="فهرست وظایف">
          {filtered.map((t) => {
            const cat = categoryInfo(t.category);
            const pr = PRIORITIES[t.priority as Priority] ?? PRIORITIES.medium;
            const due = t.dueDate ? dueLabel(t.dueDate) : null;
            return (
              <li
                key={t.id}
                className={cn(
                  "group flex items-center gap-3 rounded-xl border bg-card px-3.5 py-3 transition-all hover:shadow-sm",
                  t.completed && "opacity-60",
                )}
              >
                <Checkbox
                  checked={t.completed}
                  onCheckedChange={() => actions.toggleTask(t)}
                  aria-label={t.completed ? `لغو انجام ${t.title}` : `انجام ${t.title}`}
                  className="size-5 shrink-0"
                />
                <div className="min-w-0 flex-1">
                  <p className={cn("truncate text-sm font-semibold", t.completed && "line-through")}>
                    {t.title}
                  </p>
                  <div className="mt-1 flex flex-wrap items-center gap-1.5">
                    <Badge variant="outline" className={cn("gap-1 border-transparent", cat.badge)}>
                      {cat.emoji} {cat.label}
                    </Badge>
                    <Badge variant="outline" className={cn("border-transparent", pr.badge)}>
                      اولویت {pr.label}
                    </Badge>
                    {due ? (
                      <Badge
                        variant="outline"
                        className={cn(
                          due.tone === "over" && "border-red-300 text-red-600 dark:text-red-400",
                          due.tone === "today" && "border-primary/40 text-primary",
                          due.tone === "soon" && "border-amber-300 text-amber-700 dark:text-amber-400",
                          due.tone === "later" && "text-muted-foreground",
                        )}
                      >
                        📅 {due.text}
                      </Badge>
                    ) : null}
                  </div>
                </div>
                <Button
                  variant="ghost"
                  size="icon"
                  onClick={() => actions.deleteTask(t.id)}
                  aria-label={`حذف ${t.title}`}
                  className="size-8 shrink-0 text-muted-foreground hover:text-destructive"
                >
                  <Trash2 className="size-4" aria-hidden />
                </Button>
              </li>
            );
          })}
        </ul>
      )}
    </div>
  );
}

function CatChip({
  active,
  onClick,
  label,
  emoji,
}: {
  active: boolean;
  onClick: () => void;
  label: string;
  emoji: string;
}) {
  return (
    <button
      onClick={onClick}
      aria-pressed={active}
      className={cn(
        "shrink-0 rounded-full border px-3 py-1.5 text-xs font-semibold transition-colors min-h-[32px]",
        active
          ? "border-primary bg-primary text-primary-foreground"
          : "text-muted-foreground hover:bg-accent",
      )}
    >
      {emoji} {label}
    </button>
  );
}
