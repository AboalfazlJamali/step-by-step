"use client";

import { BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer } from "recharts";
import { ListChecks, Sprout, Target, Flame } from "lucide-react";
import { Badge } from "@/components/ui/badge";
import { Progress } from "@/components/ui/progress";
import { StatCard, EmptyState } from "./shared";
import type { ViewProps } from "../app";
import { DAY_NAMES_FA, fromISO, pct, toFaDigits } from "@/lib/stepbystep";

export function ProgressView({ stats }: ViewProps) {
  if (!stats) {
    return (
      <div className="space-y-4">
        <div className="grid gap-4 sm:grid-cols-2 lg:grid-cols-4">
          {[0, 1, 2, 3].map((i) => (
            <div key={i} className="h-24 animate-pulse rounded-2xl bg-muted" />
          ))}
        </div>
        <div className="h-72 animate-pulse rounded-2xl bg-muted" />
      </div>
    );
  }

  const taskData = stats.tasksCompletedLast7.map((d) => ({
    day: DAY_NAMES_FA[fromISO(d.date).getDay()],
    count: d.count,
  }));
  const habitData = stats.habitLogsLast7.map((d) => ({
    day: DAY_NAMES_FA[fromISO(d.date).getDay()],
    count: d.count,
  }));

  const bestStreak = stats.streaks.reduce((max, s) => Math.max(max, s.streak), 0);
  const goalsAvg = stats.goals.length
    ? Math.round(stats.goals.reduce((s, g) => s + pct(g.progress, g.target), 0) / stats.goals.length)
    : 0;
  const completedGoals = stats.goals.filter((g) => g.progress >= g.target).length;

  return (
    <div className="space-y-5" dir="rtl">
      {/* Stat cards */}
      <div className="grid grid-cols-2 gap-3 lg:grid-cols-4">
        <StatCard icon={ListChecks} label="وظایف انجام‌شده" value={toFaDigits(stats.taskCompleted)} sub={`از ${toFaDigits(stats.taskTotal)} وظیفه`} />
        <StatCard icon={Sprout} label="عادت‌های این هفته" value={`${toFaDigits(stats.habitLogsThisWeek)}/${toFaDigits(stats.habitPlannedThisWeek)}`} sub={`${toFaDigits(stats.habitCount)} عادت فعال`} />
        <StatCard icon={Target} label="میانگین اهداف" value={`${toFaDigits(goalsAvg)}٪`} sub={`${toFaDigits(completedGoals)} از ${toFaDigits(stats.goals.length)} هدف تکمیل شد`} />
        <StatCard icon={Flame} label="بهترین زنجیره" value={bestStreak > 0 ? `${toFaDigits(bestStreak)} روز` : "—"} sub="روزهای پیوسته" />
      </div>

      <div className="grid gap-5 lg:grid-cols-2">
        {/* Tasks chart */}
        <section className="rounded-2xl border bg-card p-5" dir="ltr" aria-label="نمودار وظایف انجام‌شده هفت روز گذشته">
          <div className="mb-3 text-right" dir="rtl">
            <h3 className="text-sm font-bold">وظایف انجام‌شده — ۷ روز گذشته</h3>
            <p className="text-xs text-muted-foreground">تعداد وظایفی که هر روز تیک زدی</p>
          </div>
          {stats.taskCompleted === 0 ? (
            <ChartEmpty emoji="📋" text="هنوز وظیفه‌ای تکمیل نکرده‌ای؛ از بخش وظایف شروع کن!" />
          ) : (
            <div className="h-60">
              <ResponsiveContainer width="100%" height="100%">
                <BarChart data={taskData} margin={{ top: 8, right: 8, left: -18, bottom: 0 }}>
                  <CartesianGrid strokeDasharray="3 3" stroke="var(--border)" vertical={false} />
                  <XAxis dataKey="day" tick={{ fontSize: 11, fill: "var(--muted-foreground)" }} axisLine={false} tickLine={false} reversed />
                  <YAxis allowDecimals={false} tick={{ fontSize: 11, fill: "var(--muted-foreground)" }} axisLine={false} tickLine={false} />
                  <Tooltip
                    cursor={{ fill: "var(--accent)" }}
                    contentStyle={{
                      background: "var(--popover)",
                      border: "1px solid var(--border)",
                      borderRadius: 12,
                      fontFamily: "inherit",
                      direction: "rtl",
                    }}
                    formatter={(v) => [`${toFaDigits(Number(v))} وظیفه`, "انجام‌شده"]}
                    labelFormatter={(l) => String(l)}
                  />
                  <Bar dataKey="count" fill="var(--chart-1)" radius={[6, 6, 0, 0]} maxBarSize={36} />
                </BarChart>
              </ResponsiveContainer>
            </div>
          )}
        </section>

        {/* Habits chart */}
        <section className="rounded-2xl border bg-card p-5" dir="ltr" aria-label="نمودار ثبت عادت‌ها هفت روز گذشته">
          <div className="mb-3 text-right" dir="rtl">
            <h3 className="text-sm font-bold">عادت‌های ثبت‌شده — ۷ روز گذشته</h3>
            <p className="text-xs text-muted-foreground">تعداد تیک‌های عادت‌ها در هر روز</p>
          </div>
          {stats.habitCount === 0 ? (
            <ChartEmpty emoji="🌱" text="هنوز عادتی نساخته‌ای؛ اولین عادت را بکار!" />
          ) : (
            <div className="h-60">
              <ResponsiveContainer width="100%" height="100%">
                <BarChart data={habitData} margin={{ top: 8, right: 8, left: -18, bottom: 0 }}>
                  <CartesianGrid strokeDasharray="3 3" stroke="var(--border)" vertical={false} />
                  <XAxis dataKey="day" tick={{ fontSize: 11, fill: "var(--muted-foreground)" }} axisLine={false} tickLine={false} reversed />
                  <YAxis allowDecimals={false} tick={{ fontSize: 11, fill: "var(--muted-foreground)" }} axisLine={false} tickLine={false} />
                  <Tooltip
                    cursor={{ fill: "var(--accent)" }}
                    contentStyle={{
                      background: "var(--popover)",
                      border: "1px solid var(--border)",
                      borderRadius: 12,
                      fontFamily: "inherit",
                      direction: "rtl",
                    }}
                    formatter={(v) => [`${toFaDigits(Number(v))} عادت`, "ثبت‌شده"]}
                    labelFormatter={(l) => String(l)}
                  />
                  <Bar dataKey="count" fill="var(--chart-2)" radius={[6, 6, 0, 0]} maxBarSize={36} />
                </BarChart>
              </ResponsiveContainer>
            </div>
          )}
        </section>
      </div>

      <div className="grid gap-5 lg:grid-cols-2">
        {/* Streaks */}
        <section className="rounded-2xl border bg-card p-5" aria-label="زنجیره عادت‌ها">
          <h3 className="mb-3 text-sm font-bold">🔥 زنجیره عادت‌ها</h3>
          {stats.streaks.length === 0 ? (
            <EmptyState emoji="🌱" title="عادتی برای نمایش نیست" />
          ) : (
            <ul className="space-y-2.5">
              {stats.streaks
                .slice()
                .sort((a, b) => b.streak - a.streak)
                .map((s) => (
                  <li key={s.habitId} className="flex items-center gap-2.5 rounded-lg border px-3 py-2.5">
                    <span className="text-lg" aria-hidden>{s.icon}</span>
                    <span className="flex-1 truncate text-sm font-semibold">{s.title}</span>
                    {s.streak > 0 ? (
                      <Badge variant="outline" className="border-orange-300 text-orange-600 dark:text-orange-400">
                        {toFaDigits(s.streak)} روز پیوسته
                      </Badge>
                    ) : (
                      <span className="text-xs text-muted-foreground">زنجیره‌ای فعال نیست — امروز شروع کن!</span>
                    )}
                  </li>
                ))}
            </ul>
          )}
        </section>

        {/* Goals summary */}
        <section className="rounded-2xl border bg-card p-5" aria-label="خلاصه اهداف هفته">
          <h3 className="mb-3 text-sm font-bold">🎯 پیشرفت اهداف هفته</h3>
          {stats.goals.length === 0 ? (
            <EmptyState emoji="🎯" title="هدفی برای این هفته ثبت نشده" hint="از بخش اهداف هفتگی یک هدف کوچک تعیین کن." />
          ) : (
            <ul className="space-y-4">
              {stats.goals.map((g) => {
                const p = pct(g.progress, g.target);
                return (
                  <li key={g.id} className="space-y-1.5">
                    <div className="flex items-center justify-between gap-2 text-sm">
                      <span className="truncate font-semibold">
                        {g.progress >= g.target && <span aria-hidden>🎉 </span>}
                        {g.title}
                      </span>
                      <span className="shrink-0 text-xs tabular-nums text-muted-foreground">
                        {toFaDigits(g.progress)}/{toFaDigits(g.target)} {g.unit} ({toFaDigits(p)}٪)
                      </span>
                    </div>
                    <Progress value={p} aria-label={`پیشرفت ${g.title}`} className="h-2" />
                  </li>
                );
              })}
            </ul>
          )}
        </section>
      </div>
    </div>
  );
}

function ChartEmpty({ emoji, text }: { emoji: string; text: string }) {
  return (
    <div className="flex h-60 flex-col items-center justify-center gap-2 rounded-xl border border-dashed text-center">
      <span className="text-3xl" aria-hidden>{emoji}</span>
      <p className="max-w-xs text-sm text-muted-foreground">{text}</p>
    </div>
  );
}
