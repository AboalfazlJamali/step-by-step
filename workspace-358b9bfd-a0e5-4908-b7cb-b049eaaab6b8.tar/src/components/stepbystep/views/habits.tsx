"use client";

import { useState } from "react";
import { Sprout, Trash2 } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Input } from "@/components/ui/input";
import { SectionCard, EmptyState } from "./shared";
import type { ViewProps } from "../app";
import {
  HABIT_ICONS,
  WEEK_COLUMNS_FA,
  DAY_NAMES_FA,
  formatJalali,
  fromISO,
  getPersianWeek,
  habitStreak,
  logsInWeek,
  toFaDigits,
} from "@/lib/stepbystep";
import { cn } from "@/lib/utils";

export function HabitsView({ today, habits, actions }: ViewProps) {
  const [title, setTitle] = useState("");
  const [icon, setIcon] = useState(HABIT_ICONS[0]);
  const [targetDays, setTargetDays] = useState(7);
  const [submitting, setSubmitting] = useState(false);

  const week = getPersianWeek(today);
  const todayIdx = week.indexOf(today); // 0..6 within شنبه→جمعه

  const totalPlanned = habits.reduce((s, h) => s + h.targetDays, 0);
  const totalDone = habits.reduce((s, h) => s + logsInWeek(h.logs, today), 0);

  async function submit() {
    const trimmed = title.trim();
    if (!trimmed) return;
    setSubmitting(true);
    const ok = await actions.addHabit({ title: trimmed, icon, targetDays });
    setSubmitting(false);
    if (ok) {
      setTitle("");
      setIcon(HABIT_ICONS[0]);
      setTargetDays(7);
    }
  }

  return (
    <div className="space-y-5">
      {/* Add habit */}
      <SectionCard icon={Sprout} title="عادت جدید">
        <form
          onSubmit={(e) => {
            e.preventDefault();
            submit();
          }}
          className="space-y-4"
        >
          <Input
            value={title}
            onChange={(e) => setTitle(e.target.value)}
            placeholder="مثلاً: هر روز ۲۰ صفحه کتاب بخوانم"
            aria-label="عنوان عادت"
            maxLength={200}
            className="h-11"
          />
          <div className="space-y-2">
            <span className="text-xs font-medium text-muted-foreground">آیکون عادت را انتخاب کن:</span>
            <div className="flex flex-wrap gap-1.5" role="radiogroup" aria-label="انتخاب آیکون">
              {HABIT_ICONS.map((ic) => (
                <button
                  key={ic}
                  type="button"
                  role="radio"
                  aria-checked={icon === ic}
                  onClick={() => setIcon(ic)}
                  className={cn(
                    "flex size-10 items-center justify-center rounded-xl border text-lg transition-all hover:scale-105 active:scale-95",
                    icon === ic
                      ? "border-primary bg-primary/10 ring-2 ring-primary/30"
                      : "bg-card",
                  )}
                >
                  {ic}
                </button>
              ))}
            </div>
          </div>
          <div className="space-y-2">
            <span className="text-xs font-medium text-muted-foreground">هدف هفتگی:</span>
            <div className="flex flex-wrap gap-1.5">
              {[1, 2, 3, 4, 5, 6, 7].map((d) => (
                <button
                  key={d}
                  type="button"
                  onClick={() => setTargetDays(d)}
                  aria-pressed={targetDays === d}
                  className={cn(
                    "rounded-full border px-3.5 py-1.5 text-xs font-semibold transition-colors min-h-[32px]",
                    targetDays === d
                      ? "border-primary bg-primary text-primary-foreground"
                      : "text-muted-foreground hover:bg-accent",
                  )}
                >
                  {toFaDigits(d)} روز
                </button>
              ))}
            </div>
          </div>
          <Button type="submit" disabled={!title.trim() || submitting} className="h-11 w-full gap-1.5 sm:w-auto">
            <Sprout className="size-4" aria-hidden />
            کاشتن این عادت
          </Button>
        </form>
      </SectionCard>

      {/* Weekly grid */}
      <SectionCard
        icon={Sprout}
        title="جدول هفتگی عادت‌ها"
        contentClassName="space-y-3"
      >
        <div className="flex flex-wrap items-center justify-between gap-2">
          <p className="text-xs text-muted-foreground">
            هفته: {formatJalali(week[0], { day: "numeric", month: "long" })} تا{" "}
            {formatJalali(week[6], { day: "numeric", month: "long" })}
          </p>
          <Badge variant="outline" className="tabular-nums">
            {toFaDigits(totalDone)}/{toFaDigits(totalPlanned)} این هفته
          </Badge>
        </div>

        {habits.length === 0 ? (
          <EmptyState
            emoji="🌱"
            title="هنوز عادتی نساخته‌ای"
            hint="از یک عادت کوچک شروع کن — مثل «نوشیدن ۸ لیوان آب» — و هر روز آن را تیک بزن."
          />
        ) : (
          <div className="scrollbar-thin -mx-1 overflow-x-auto px-1 pb-1">
            <table className="w-full min-w-[480px] border-separate border-spacing-y-1.5">
              <caption className="sr-only">جدول ثبت روزانه عادت‌ها در هفته جاری</caption>
              <thead>
                <tr>
                  <th scope="col" className="w-1/3 min-w-44 text-right text-xs font-medium text-muted-foreground">
                    عادت
                  </th>
                  {WEEK_COLUMNS_FA.map((d, i) => (
                    <th
                      key={i}
                      scope="col"
                      className={cn(
                        "w-9 pb-1 text-center text-xs font-bold",
                        i === todayIdx ? "text-primary" : "text-muted-foreground",
                      )}
                      title={DAY_NAMES_FA[fromISO(week[i]).getDay()]}
                    >
                      {d}
                    </th>
                  ))}
                  <th scope="col" className="w-16 pb-1 text-center text-xs font-medium text-muted-foreground">
                    زنجیره
                  </th>
                  <th scope="col" className="w-10" aria-hidden />
                </tr>
              </thead>
              <tbody>
                {habits.map((h) => {
                  const logged = new Set(h.logs.map((l) => l.date));
                  const streak = habitStreak(h.logs);
                  const weekDone = logsInWeek(h.logs, today);
                  const hitTarget = weekDone >= h.targetDays;
                  return (
                    <tr key={h.id} className="group">
                      <td className="rounded-r-xl border bg-card px-3 py-2">
                        <div className="flex items-center gap-2">
                          <span className="text-lg" aria-hidden>{h.icon}</span>
                          <div className="min-w-0">
                            <p className="truncate text-sm font-semibold">{h.title}</p>
                            <p className={cn("text-[11px] tabular-nums", hitTarget ? "font-bold text-primary" : "text-muted-foreground")}>
                              {toFaDigits(weekDone)}/{toFaDigits(h.targetDays)} روز این هفته
                            </p>
                          </div>
                        </div>
                      </td>
                      {week.map((d, i) => {
                        const done = logged.has(d);
                        const isToday = d === today;
                        return (
                          <td key={d} className="px-0.5 text-center">
                            <button
                              onClick={() => actions.toggleHabit(h.id, d)}
                              aria-pressed={done}
                              aria-label={`${h.title} — ${DAY_NAMES_FA[fromISO(d).getDay()]} ${formatJalali(d, { day: "numeric", month: "long" })}`}
                              className={cn(
                                "flex size-9 items-center justify-center rounded-lg border text-sm font-bold transition-all hover:border-primary/60 active:scale-90",
                                done
                                  ? "border-primary bg-primary text-primary-foreground"
                                  : "bg-card",
                                isToday && !done && "border-primary/50 ring-1 ring-primary/25",
                                isToday && done && "ring-2 ring-primary/30",
                              )}
                            >
                              {done ? "✓" : ""}
                            </button>
                          </td>
                        );
                      })}
                      <td className="rounded-l-xl border bg-card px-2 py-2 text-center">
                        <span className={cn("text-sm font-bold tabular-nums", streak > 0 ? "text-orange-500" : "text-muted-foreground")}>
                          {streak > 0 ? `🔥${toFaDigits(streak)}` : "—"}
                        </span>
                      </td>
                      <td className="py-1 pr-1">
                        <Button
                          variant="ghost"
                          size="icon"
                          onClick={() => actions.deleteHabit(h.id)}
                          aria-label={`حذف عادت ${h.title}`}
                          className="size-7 text-muted-foreground opacity-0 transition-opacity hover:text-destructive group-hover:opacity-100 focus:opacity-100"
                        >
                          <Trash2 className="size-3.5" aria-hidden />
                        </Button>
                      </td>
                    </tr>
                  );
                })}
              </tbody>
            </table>
          </div>
        )}
        {habits.length > 0 ? (
          <p className="text-xs text-muted-foreground">
            💡 روی خانه‌های جدول بزن تا عادت هر روز ثبت یا حذف شود. ستون امروز با دور سبز مشخص است.
          </p>
        ) : null}
      </SectionCard>
    </div>
  );
}

