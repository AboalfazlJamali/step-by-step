import { StepByStepApp } from "@/components/stepbystep/app";

export default function Page() {
  return <StepByStepApp />;
}
