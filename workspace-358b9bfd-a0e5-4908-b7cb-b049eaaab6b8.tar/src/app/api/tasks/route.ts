import { db } from '@/lib/db'

const DATE_RE = /^\d{4}-\d{2}-\d{2}$/
const CATEGORIES: readonly string[] = ['study', 'homework', 'exercise', 'rest', 'other']
const PRIORITIES: readonly string[] = ['low', 'medium', 'high']

// priority rank for sorting: high > medium > low
const PRIORITY_RANK: Record<string, number> = { high: 0, medium: 1, low: 2 }

export async function GET() {
  try {
    const tasks = await db.task.findMany({ orderBy: { createdAt: 'desc' } })
    // incomplete first, then priority high→low, then createdAt desc
    tasks.sort((a, b) => {
      if (a.completed !== b.completed) return a.completed ? 1 : -1
      const pa = PRIORITY_RANK[a.priority] ?? 1
      const pb = PRIORITY_RANK[b.priority] ?? 1
      if (pa !== pb) return pa - pb
      return new Date(b.createdAt).getTime() - new Date(a.createdAt).getTime()
    })
    return Response.json({ tasks })
  } catch {
    return Response.json({ error: 'خطای سرور' }, { status: 500 })
  }
}

export async function POST(request: Request) {
  try {
    const body = await request.json().catch(() => null)
    if (!body || typeof body !== 'object') {
      return Response.json({ error: 'داده ارسالی نامعتبر است' }, { status: 400 })
    }
    const b = body as Record<string, unknown>

    const title = typeof b.title === 'string' ? b.title.trim() : ''
    if (!title) {
      return Response.json({ error: 'عنوان الزامی است' }, { status: 400 })
    }
    if (title.length > 200) {
      return Response.json({ error: 'عنوان باید حداکثر ۲۰۰ کاراکتر باشد' }, { status: 400 })
    }

    let description: string | null = null
    if (b.description !== undefined && b.description !== null) {
      if (typeof b.description !== 'string') {
        return Response.json({ error: 'توضیحات باید متن باشد' }, { status: 400 })
      }
      description = b.description
    }

    let category = 'other'
    if (b.category !== undefined) {
      if (typeof b.category !== 'string' || !CATEGORIES.includes(b.category)) {
        return Response.json({ error: 'دسته‌بندی نامعتبر است' }, { status: 400 })
      }
      category = b.category
    }

    let priority = 'medium'
    if (b.priority !== undefined) {
      if (typeof b.priority !== 'string' || !PRIORITIES.includes(b.priority)) {
        return Response.json({ error: 'اولویت نامعتبر است' }, { status: 400 })
      }
      priority = b.priority
    }

    let dueDate: string | null = null
    if (b.dueDate !== undefined && b.dueDate !== null) {
      if (typeof b.dueDate !== 'string' || !DATE_RE.test(b.dueDate)) {
        return Response.json({ error: 'قالب تاریخ باید yyyy-mm-dd باشد' }, { status: 400 })
      }
      dueDate = b.dueDate
    }

    const task = await db.task.create({
      data: { title, description, category, priority, dueDate },
    })
    return Response.json({ task }, { status: 201 })
  } catch {
    return Response.json({ error: 'خطای سرور' }, { status: 500 })
  }
}
