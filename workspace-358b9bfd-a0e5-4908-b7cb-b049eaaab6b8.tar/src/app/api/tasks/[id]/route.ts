import { db } from '@/lib/db'

const DATE_RE = /^\d{4}-\d{2}-\d{2}$/
const CATEGORIES: readonly string[] = ['study', 'homework', 'exercise', 'rest', 'other']
const PRIORITIES: readonly string[] = ['low', 'medium', 'high']

type Ctx = { params: Promise<{ id: string }> }

export async function PATCH(request: Request, { params }: Ctx) {
  try {
    const { id } = await params
    const body = await request.json().catch(() => null)
    if (!body || typeof body !== 'object') {
      return Response.json({ error: 'داده ارسالی نامعتبر است' }, { status: 400 })
    }
    const b = body as Record<string, unknown>

    const existing = await db.task.findUnique({ where: { id } })
    if (!existing) {
      return Response.json({ error: 'وظیفه یافت نشد' }, { status: 404 })
    }

    const data: {
      title?: string
      description?: string | null
      category?: string
      priority?: string
      dueDate?: string | null
      completed?: boolean
      completedAt?: Date | null
    } = {}

    if (b.title !== undefined) {
      if (typeof b.title !== 'string') {
        return Response.json({ error: 'عنوان باید متن باشد' }, { status: 400 })
      }
      const title = b.title.trim()
      if (!title) {
        return Response.json({ error: 'عنوان الزامی است' }, { status: 400 })
      }
      if (title.length > 200) {
        return Response.json({ error: 'عنوان باید حداکثر ۲۰۰ کاراکتر باشد' }, { status: 400 })
      }
      data.title = title
    }

    if (b.description !== undefined) {
      if (b.description !== null && typeof b.description !== 'string') {
        return Response.json({ error: 'توضیحات باید متن باشد' }, { status: 400 })
      }
      data.description = b.description === null ? null : b.description
    }

    if (b.category !== undefined) {
      if (typeof b.category !== 'string' || !CATEGORIES.includes(b.category)) {
        return Response.json({ error: 'دسته‌بندی نامعتبر است' }, { status: 400 })
      }
      data.category = b.category
    }

    if (b.priority !== undefined) {
      if (typeof b.priority !== 'string' || !PRIORITIES.includes(b.priority)) {
        return Response.json({ error: 'اولویت نامعتبر است' }, { status: 400 })
      }
      data.priority = b.priority
    }

    if (b.dueDate !== undefined) {
      if (b.dueDate !== null && (typeof b.dueDate !== 'string' || !DATE_RE.test(b.dueDate))) {
        return Response.json({ error: 'قالب تاریخ باید yyyy-mm-dd باشد' }, { status: 400 })
      }
      data.dueDate = b.dueDate === null ? null : b.dueDate
    }

    if (b.completed !== undefined) {
      if (typeof b.completed !== 'boolean') {
        return Response.json({ error: 'وضعیت انجام باید بولی باشد' }, { status: 400 })
      }
      data.completed = b.completed
      data.completedAt = b.completed ? new Date() : null
    }

    const task = await db.task.update({ where: { id }, data })
    return Response.json({ task })
  } catch {
    return Response.json({ error: 'خطای سرور' }, { status: 500 })
  }
}

export async function DELETE(_request: Request, { params }: Ctx) {
  try {
    const { id } = await params
    const existing = await db.task.findUnique({ where: { id } })
    if (!existing) {
      return Response.json({ error: 'وظیفه یافت نشد' }, { status: 404 })
    }
    await db.task.delete({ where: { id } })
    return Response.json({ ok: true })
  } catch {
    return Response.json({ error: 'خطای سرور' }, { status: 500 })
  }
}
