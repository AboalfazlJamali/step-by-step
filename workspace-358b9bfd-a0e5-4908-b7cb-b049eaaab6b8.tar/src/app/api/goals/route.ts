import { db } from '@/lib/db'

const DATE_RE = /^\d{4}-\d{2}-\d{2}$/
const MAX_TARGET = 10000

function localISODate(d: Date): string {
  const y = d.getFullYear()
  const m = String(d.getMonth() + 1).padStart(2, '0')
  const day = String(d.getDate()).padStart(2, '0')
  return `${y}-${m}-${day}`
}

// current Persian week Saturday (شنبه) as yyyy-mm-dd
function currentWeekStartISO(): string {
  const now = new Date()
  const diff = (now.getDay() + 1) % 7
  const sat = new Date(now)
  sat.setDate(now.getDate() - diff)
  return localISODate(sat)
}

export async function GET(request: Request) {
  try {
    const url = new URL(request.url)
    let weekStart = url.searchParams.get('weekStart') ?? ''
    if (!weekStart) {
      weekStart = currentWeekStartISO()
    } else if (!DATE_RE.test(weekStart)) {
      return Response.json({ error: 'قالب weekStart باید yyyy-mm-dd باشد' }, { status: 400 })
    }
    const goals = await db.goal.findMany({
      where: { weekStart },
      orderBy: { createdAt: 'asc' },
    })
    return Response.json({ goals, weekStart })
  } catch {
    return Response.json({ error: 'خطای سرور' }, { status: 500 })
  }
}

export async function POST(request: Request) {
  try {
    const body = await request.json().catch(() => null)
    if (!body || typeof body !== 'object') {
      return Response.json({ error: 'داده ارسالی نامعتبر است' }, { status: 400 })
    }
    const b = body as Record<string, unknown>

    const title = typeof b.title === 'string' ? b.title.trim() : ''
    if (!title) {
      return Response.json({ error: 'عنوان الزامی است' }, { status: 400 })
    }
    if (title.length > 200) {
      return Response.json({ error: 'عنوان باید حداکثر ۲۰۰ کاراکتر باشد' }, { status: 400 })
    }

    let target = 1
    if (b.target !== undefined) {
      if (typeof b.target !== 'number' || !Number.isFinite(b.target)) {
        return Response.json({ error: 'هدف باید عدد باشد' }, { status: 400 })
      }
      // int >= 1, clamped to a reasonable max
      target = Math.min(MAX_TARGET, Math.max(1, Math.round(b.target)))
    }

    let unit = 'مرتبه'
    if (b.unit !== undefined) {
      if (typeof b.unit !== 'string' || b.unit.trim() === '') {
        return Response.json({ error: 'واحد باید متن باشد' }, { status: 400 })
      }
      unit = b.unit.trim()
    }

    let weekStart = currentWeekStartISO()
    if (b.weekStart !== undefined) {
      if (typeof b.weekStart !== 'string' || !DATE_RE.test(b.weekStart)) {
        return Response.json({ error: 'قالب weekStart باید yyyy-mm-dd باشد' }, { status: 400 })
      }
      weekStart = b.weekStart
    }

    const goal = await db.goal.create({
      data: { title, target, unit, weekStart },
    })
    return Response.json({ goal }, { status: 201 })
  } catch {
    return Response.json({ error: 'خطای سرور' }, { status: 500 })
  }
}
