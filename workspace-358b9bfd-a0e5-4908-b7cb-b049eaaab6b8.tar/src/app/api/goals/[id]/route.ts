import { db } from '@/lib/db'

const MAX_TARGET = 10000

type Ctx = { params: Promise<{ id: string }> }

export async function PATCH(request: Request, { params }: Ctx) {
  try {
    const { id } = await params
    const body = await request.json().catch(() => null)
    if (!body || typeof body !== 'object') {
      return Response.json({ error: 'داده ارسالی نامعتبر است' }, { status: 400 })
    }
    const b = body as Record<string, unknown>

    const existing = await db.goal.findUnique({ where: { id } })
    if (!existing) {
      return Response.json({ error: 'هدف یافت نشد' }, { status: 404 })
    }

    const data: {
      title?: string
      target?: number
      progress?: number
      unit?: string
    } = {}

    if (b.title !== undefined) {
      if (typeof b.title !== 'string') {
        return Response.json({ error: 'عنوان باید متن باشد' }, { status: 400 })
      }
      const title = b.title.trim()
      if (!title) {
        return Response.json({ error: 'عنوان الزامی است' }, { status: 400 })
      }
      if (title.length > 200) {
        return Response.json({ error: 'عنوان باید حداکثر ۲۰۰ کاراکتر باشد' }, { status: 400 })
      }
      data.title = title
    }

    let effectiveTarget = existing.target
    if (b.target !== undefined) {
      if (typeof b.target !== 'number' || !Number.isFinite(b.target)) {
        return Response.json({ error: 'هدف باید عدد باشد' }, { status: 400 })
      }
      const target = Math.min(MAX_TARGET, Math.max(1, Math.round(b.target)))
      data.target = target
      effectiveTarget = target
    }

    if (b.progress !== undefined) {
      if (typeof b.progress !== 'number' || !Number.isFinite(b.progress)) {
        return Response.json({ error: 'پیشرفت باید عدد باشد' }, { status: 400 })
      }
      // clamp 0..effectiveTarget (new target if provided, else current)
      data.progress = Math.min(effectiveTarget, Math.max(0, Math.round(b.progress)))
    }

    if (b.unit !== undefined) {
      if (typeof b.unit !== 'string' || b.unit.trim() === '') {
        return Response.json({ error: 'واحد باید متن باشد' }, { status: 400 })
      }
      data.unit = b.unit.trim()
    }

    const goal = await db.goal.update({ where: { id }, data })
    return Response.json({ goal })
  } catch {
    return Response.json({ error: 'خطای سرور' }, { status: 500 })
  }
}

export async function DELETE(_request: Request, { params }: Ctx) {
  try {
    const { id } = await params
    const existing = await db.goal.findUnique({ where: { id } })
    if (!existing) {
      return Response.json({ error: 'هدف یافت نشد' }, { status: 404 })
    }
    await db.goal.delete({ where: { id } })
    return Response.json({ ok: true })
  } catch {
    return Response.json({ error: 'خطای سرور' }, { status: 500 })
  }
}
