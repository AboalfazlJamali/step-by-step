import { db } from '@/lib/db'

// habit logs are limited to the last 35 days
const LOG_WINDOW_DAYS = 35

function localISODate(d: Date): string {
  const y = d.getFullYear()
  const m = String(d.getMonth() + 1).padStart(2, '0')
  const day = String(d.getDate()).padStart(2, '0')
  return `${y}-${m}-${day}`
}

function logsCutoffISO(): string {
  const d = new Date()
  d.setDate(d.getDate() - LOG_WINDOW_DAYS)
  return localISODate(d)
}

export async function GET() {
  try {
    const habits = await db.habit.findMany({
      include: {
        logs: {
          where: { date: { gte: logsCutoffISO() } },
          orderBy: { date: 'desc' },
        },
      },
      orderBy: { createdAt: 'asc' },
    })
    return Response.json({ habits })
  } catch {
    return Response.json({ error: 'خطای سرور' }, { status: 500 })
  }
}

export async function POST(request: Request) {
  try {
    const body = await request.json().catch(() => null)
    if (!body || typeof body !== 'object') {
      return Response.json({ error: 'داده ارسالی نامعتبر است' }, { status: 400 })
    }
    const b = body as Record<string, unknown>

    const title = typeof b.title === 'string' ? b.title.trim() : ''
    if (!title) {
      return Response.json({ error: 'عنوان الزامی است' }, { status: 400 })
    }
    if (title.length > 200) {
      return Response.json({ error: 'عنوان باید حداکثر ۲۰۰ کاراکتر باشد' }, { status: 400 })
    }

    let icon = '🌱'
    if (b.icon !== undefined) {
      if (typeof b.icon !== 'string' || b.icon.trim() === '') {
        return Response.json({ error: 'آیکون باید متن باشد' }, { status: 400 })
      }
      icon = b.icon
    }

    let targetDays = 7
    if (b.targetDays !== undefined) {
      if (typeof b.targetDays !== 'number' || !Number.isFinite(b.targetDays)) {
        return Response.json({ error: 'تعداد روز هدف باید عدد باشد' }, { status: 400 })
      }
      // clamp 1..7
      targetDays = Math.min(7, Math.max(1, Math.round(b.targetDays)))
    }

    const habit = await db.habit.create({
      data: { title, icon, targetDays },
      include: { logs: true },
    })
    return Response.json({ habit }, { status: 201 })
  } catch {
    return Response.json({ error: 'خطای سرور' }, { status: 500 })
  }
}
