import { db } from '@/lib/db'

// habit logs are limited to the last 35 days
const LOG_WINDOW_DAYS = 35

function localISODate(d: Date): string {
  const y = d.getFullYear()
  const m = String(d.getMonth() + 1).padStart(2, '0')
  const day = String(d.getDate()).padStart(2, '0')
  return `${y}-${m}-${day}`
}

function logsCutoffISO(): string {
  const d = new Date()
  d.setDate(d.getDate() - LOG_WINDOW_DAYS)
  return localISODate(d)
}

type Ctx = { params: Promise<{ id: string }> }

export async function PATCH(request: Request, { params }: Ctx) {
  try {
    const { id } = await params
    const body = await request.json().catch(() => null)
    if (!body || typeof body !== 'object') {
      return Response.json({ error: 'داده ارسالی نامعتبر است' }, { status: 400 })
    }
    const b = body as Record<string, unknown>

    const existing = await db.habit.findUnique({ where: { id } })
    if (!existing) {
      return Response.json({ error: 'عادت یافت نشد' }, { status: 404 })
    }

    const data: {
      title?: string
      icon?: string
      targetDays?: number
    } = {}

    if (b.title !== undefined) {
      if (typeof b.title !== 'string') {
        return Response.json({ error: 'عنوان باید متن باشد' }, { status: 400 })
      }
      const title = b.title.trim()
      if (!title) {
        return Response.json({ error: 'عنوان الزامی است' }, { status: 400 })
      }
      if (title.length > 200) {
        return Response.json({ error: 'عنوان باید حداکثر ۲۰۰ کاراکتر باشد' }, { status: 400 })
      }
      data.title = title
    }

    if (b.icon !== undefined) {
      if (typeof b.icon !== 'string' || b.icon.trim() === '') {
        return Response.json({ error: 'آیکون باید متن باشد' }, { status: 400 })
      }
      data.icon = b.icon
    }

    if (b.targetDays !== undefined) {
      if (typeof b.targetDays !== 'number' || !Number.isFinite(b.targetDays)) {
        return Response.json({ error: 'تعداد روز هدف باید عدد باشد' }, { status: 400 })
      }
      // clamp 1..7
      data.targetDays = Math.min(7, Math.max(1, Math.round(b.targetDays)))
    }

    const habit = await db.habit.update({
      where: { id },
      data,
      include: {
        logs: {
          where: { date: { gte: logsCutoffISO() } },
          orderBy: { date: 'desc' },
        },
      },
    })
    return Response.json({ habit })
  } catch {
    return Response.json({ error: 'خطای سرور' }, { status: 500 })
  }
}

export async function DELETE(_request: Request, { params }: Ctx) {
  try {
    const { id } = await params
    const existing = await db.habit.findUnique({ where: { id } })
    if (!existing) {
      return Response.json({ error: 'عادت یافت نشد' }, { status: 404 })
    }
    await db.habit.delete({ where: { id } })
    return Response.json({ ok: true })
  } catch {
    return Response.json({ error: 'خطای سرور' }, { status: 500 })
  }
}
