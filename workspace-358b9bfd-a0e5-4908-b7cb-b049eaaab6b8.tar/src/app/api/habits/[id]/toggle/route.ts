import { db } from '@/lib/db'

const DATE_RE = /^\d{4}-\d{2}-\d{2}$/

// habit logs are limited to the last 35 days
const LOG_WINDOW_DAYS = 35

function localISODate(d: Date): string {
  const y = d.getFullYear()
  const m = String(d.getMonth() + 1).padStart(2, '0')
  const day = String(d.getDate()).padStart(2, '0')
  return `${y}-${m}-${day}`
}

function logsCutoffISO(): string {
  const d = new Date()
  d.setDate(d.getDate() - LOG_WINDOW_DAYS)
  return localISODate(d)
}

type Ctx = { params: Promise<{ id: string }> }

// POST /api/habits/[id]/toggle { date } — creates the daily log if missing, deletes it if it exists
export async function POST(request: Request, { params }: Ctx) {
  try {
    const { id } = await params
    const body = await request.json().catch(() => null)
    if (!body || typeof body !== 'object') {
      return Response.json({ error: 'داده ارسالی نامعتبر است' }, { status: 400 })
    }
    const b = body as Record<string, unknown>

    if (typeof b.date !== 'string' || !DATE_RE.test(b.date)) {
      return Response.json({ error: 'تاریخ الزامی است و باید قالب yyyy-mm-dd باشد' }, { status: 400 })
    }
    const date = b.date

    const habit = await db.habit.findUnique({ where: { id } })
    if (!habit) {
      return Response.json({ error: 'عادت یافت نشد' }, { status: 404 })
    }

    const log = await db.habitLog.findUnique({
      where: { habitId_date: { habitId: id, date } },
    })
    if (log) {
      await db.habitLog.delete({ where: { id: log.id } })
    } else {
      await db.habitLog.create({ data: { habitId: id, date } })
    }

    const updated = await db.habit.findUnique({
      where: { id },
      include: {
        logs: {
          where: { date: { gte: logsCutoffISO() } },
          orderBy: { date: 'desc' },
        },
      },
    })
    return Response.json({ habit: updated })
  } catch {
    return Response.json({ error: 'خطای سرور' }, { status: 500 })
  }
}
