import { db } from '@/lib/db'

export const dynamic = 'force-dynamic'

function localISODate(d: Date): string {
  const y = d.getFullYear()
  const m = String(d.getMonth() + 1).padStart(2, '0')
  const day = String(d.getDate()).padStart(2, '0')
  return `${y}-${m}-${day}`
}

// parse "yyyy-mm-dd" into a local Date (avoid UTC shifting)
function parseISODate(s: string): Date {
  const [y, m, d] = s.split('-').map(Number)
  return new Date(y, m - 1, d)
}

// current Persian week Saturday (شنبه) as yyyy-mm-dd
function currentWeekStartISO(): string {
  const now = new Date()
  const diff = (now.getDay() + 1) % 7
  const sat = new Date(now)
  sat.setDate(now.getDate() - diff)
  return localISODate(sat)
}

export async function GET() {
  try {
    const now = new Date()
    const today = localISODate(now)
    const yesterdayDate = new Date(now)
    yesterdayDate.setDate(now.getDate() - 1)
    const yesterday = localISODate(yesterdayDate)

    // last 7 dates, oldest → newest (today-6 … today)
    const dates7: string[] = []
    for (let i = 6; i >= 0; i--) {
      const d = new Date(now)
      d.setDate(now.getDate() - i)
      dates7.push(localISODate(d))
    }

    // current Persian week range (Saturday .. Friday)
    const weekStart = currentWeekStartISO()
    const weekEndDate = parseISODate(weekStart)
    weekEndDate.setDate(weekEndDate.getDate() + 6)
    const weekEnd = localISODate(weekEndDate)

    const [taskTotal, taskCompleted, taskDueToday] = await Promise.all([
      db.task.count(),
      db.task.count({ where: { completed: true } }),
      db.task.count({ where: { completed: false, dueDate: today } }),
    ])

    // tasks completed per day over the last 7 days (group in JS by local date of completedAt)
    const completedTasks = await db.task.findMany({
      where: { completed: true },
      select: { completedAt: true },
    })
    const completedByDate = new Map<string, number>()
    for (const t of completedTasks) {
      if (!t.completedAt) continue
      const key = localISODate(t.completedAt)
      completedByDate.set(key, (completedByDate.get(key) ?? 0) + 1)
    }
    const tasksCompletedLast7 = dates7.map((date) => ({
      date,
      count: completedByDate.get(date) ?? 0,
    }))

    // habit logs per day over the last 7 days
    const recentLogs = await db.habitLog.findMany({
      where: { date: { gte: dates7[0] } },
      select: { date: true },
    })
    const logsByDate = new Map<string, number>()
    for (const log of recentLogs) {
      logsByDate.set(log.date, (logsByDate.get(log.date) ?? 0) + 1)
    }
    const habitLogsLast7 = dates7.map((date) => ({
      date,
      count: logsByDate.get(date) ?? 0,
    }))

    // habits + weekly totals + streaks
    const habits = await db.habit.findMany({ include: { logs: true } })
    const habitCount = habits.length
    const habitPlannedThisWeek = habits.reduce((sum, h) => sum + h.targetDays, 0)

    let habitLogsThisWeek = 0
    for (const h of habits) {
      for (const log of h.logs) {
        if (log.date >= weekStart && log.date <= weekEnd) habitLogsThisWeek++
      }
    }

    const streaks = habits.map((h) => {
      const logged = new Set(h.logs.map((l) => l.date))
      // streak anchored on today if logged, otherwise yesterday; 0 if neither
      const anchor = logged.has(today) ? today : logged.has(yesterday) ? yesterday : null
      let streak = 0
      if (anchor) {
        const cur = parseISODate(anchor)
        while (logged.has(localISODate(cur))) {
          streak++
          cur.setDate(cur.getDate() - 1)
        }
      }
      return { habitId: h.id, title: h.title, icon: h.icon, streak }
    })

    const goals = await db.goal.findMany({
      where: { weekStart },
      orderBy: { createdAt: 'asc' },
    })

    return Response.json({
      taskTotal,
      taskCompleted,
      taskDueToday,
      tasksCompletedLast7,
      habitLogsLast7,
      habitCount,
      habitLogsThisWeek,
      habitPlannedThisWeek,
      goals,
      streaks,
    })
  } catch {
    return Response.json({ error: 'خطای سرور' }, { status: 500 })
  }
}
