import { db } from '@/lib/db'

const DATE_RE = /^\d{4}-\d{2}-\d{2}$/
const TIME_RE = /^\d{2}:\d{2}$/
const CATEGORIES: readonly string[] = ['study', 'homework', 'exercise', 'rest', 'other']

function isValidTime(t: string): boolean {
  if (!TIME_RE.test(t)) return false
  const [h, m] = t.split(':').map(Number)
  return h >= 0 && h <= 23 && m >= 0 && m <= 59
}

export async function GET(request: Request) {
  try {
    const url = new URL(request.url)
    const date = url.searchParams.get('date')
    if (!date) {
      return Response.json({ error: 'پارامتر date الزامی است' }, { status: 400 })
    }
    if (!DATE_RE.test(date)) {
      return Response.json({ error: 'قالب تاریخ باید yyyy-mm-dd باشد' }, { status: 400 })
    }
    const blocks = await db.scheduleBlock.findMany({
      where: { date },
      orderBy: { startTime: 'asc' },
    })
    return Response.json({ blocks })
  } catch {
    return Response.json({ error: 'خطای سرور' }, { status: 500 })
  }
}

export async function POST(request: Request) {
  try {
    const body = await request.json().catch(() => null)
    if (!body || typeof body !== 'object') {
      return Response.json({ error: 'داده ارسالی نامعتبر است' }, { status: 400 })
    }
    const b = body as Record<string, unknown>

    if (typeof b.date !== 'string' || !DATE_RE.test(b.date)) {
      return Response.json({ error: 'تاریخ الزامی است و باید قالب yyyy-mm-dd باشد' }, { status: 400 })
    }
    if (typeof b.startTime !== 'string' || !isValidTime(b.startTime)) {
      return Response.json({ error: 'ساعت شروع الزامی است و باید قالب HH:mm باشد' }, { status: 400 })
    }
    if (typeof b.endTime !== 'string' || !isValidTime(b.endTime)) {
      return Response.json({ error: 'ساعت پایان الزامی است و باید قالب HH:mm باشد' }, { status: 400 })
    }
    if (b.endTime <= b.startTime) {
      return Response.json({ error: 'ساعت پایان باید بعد از ساعت شروع باشد' }, { status: 400 })
    }

    const title = typeof b.title === 'string' ? b.title.trim() : ''
    if (!title) {
      return Response.json({ error: 'عنوان الزامی است' }, { status: 400 })
    }
    if (title.length > 200) {
      return Response.json({ error: 'عنوان باید حداکثر ۲۰۰ کاراکتر باشد' }, { status: 400 })
    }

    let category = 'study'
    if (b.category !== undefined) {
      if (typeof b.category !== 'string' || !CATEGORIES.includes(b.category)) {
        return Response.json({ error: 'دسته‌بندی نامعتبر است' }, { status: 400 })
      }
      category = b.category
    }

    let note: string | null = null
    if (b.note !== undefined && b.note !== null) {
      if (typeof b.note !== 'string') {
        return Response.json({ error: 'یادداشت باید متن باشد' }, { status: 400 })
      }
      note = b.note
    }

    const block = await db.scheduleBlock.create({
      data: { date: b.date, startTime: b.startTime, endTime: b.endTime, title, category, note },
    })
    return Response.json({ block }, { status: 201 })
  } catch {
    return Response.json({ error: 'خطای سرور' }, { status: 500 })
  }
}
