import { db } from '@/lib/db'

const DATE_RE = /^\d{4}-\d{2}-\d{2}$/
const TIME_RE = /^\d{2}:\d{2}$/
const CATEGORIES: readonly string[] = ['study', 'homework', 'exercise', 'rest', 'other']

function isValidTime(t: string): boolean {
  if (!TIME_RE.test(t)) return false
  const [h, m] = t.split(':').map(Number)
  return h >= 0 && h <= 23 && m >= 0 && m <= 59
}

type Ctx = { params: Promise<{ id: string }> }

export async function PATCH(request: Request, { params }: Ctx) {
  try {
    const { id } = await params
    const body = await request.json().catch(() => null)
    if (!body || typeof body !== 'object') {
      return Response.json({ error: 'داده ارسالی نامعتبر است' }, { status: 400 })
    }
    const b = body as Record<string, unknown>

    const existing = await db.scheduleBlock.findUnique({ where: { id } })
    if (!existing) {
      return Response.json({ error: 'بلوک زمانی یافت نشد' }, { status: 404 })
    }

    const data: {
      date?: string
      startTime?: string
      endTime?: string
      title?: string
      category?: string
      note?: string | null
      completed?: boolean
    } = {}

    if (b.date !== undefined) {
      if (typeof b.date !== 'string' || !DATE_RE.test(b.date)) {
        return Response.json({ error: 'قالب تاریخ باید yyyy-mm-dd باشد' }, { status: 400 })
      }
      data.date = b.date
    }

    if (b.startTime !== undefined) {
      if (typeof b.startTime !== 'string' || !isValidTime(b.startTime)) {
        return Response.json({ error: 'ساعت شروع باید قالب HH:mm باشد' }, { status: 400 })
      }
      data.startTime = b.startTime
    }

    if (b.endTime !== undefined) {
      if (typeof b.endTime !== 'string' || !isValidTime(b.endTime)) {
        return Response.json({ error: 'ساعت پایان باید قالب HH:mm باشد' }, { status: 400 })
      }
      data.endTime = b.endTime
    }

    // validate effective time range when either time is being changed
    if (data.startTime !== undefined || data.endTime !== undefined) {
      const effStart = data.startTime ?? existing.startTime
      const effEnd = data.endTime ?? existing.endTime
      if (effEnd <= effStart) {
        return Response.json({ error: 'ساعت پایان باید بعد از ساعت شروع باشد' }, { status: 400 })
      }
    }

    if (b.title !== undefined) {
      if (typeof b.title !== 'string') {
        return Response.json({ error: 'عنوان باید متن باشد' }, { status: 400 })
      }
      const title = b.title.trim()
      if (!title) {
        return Response.json({ error: 'عنوان الزامی است' }, { status: 400 })
      }
      if (title.length > 200) {
        return Response.json({ error: 'عنوان باید حداکثر ۲۰۰ کاراکتر باشد' }, { status: 400 })
      }
      data.title = title
    }

    if (b.category !== undefined) {
      if (typeof b.category !== 'string' || !CATEGORIES.includes(b.category)) {
        return Response.json({ error: 'دسته‌بندی نامعتبر است' }, { status: 400 })
      }
      data.category = b.category
    }

    if (b.note !== undefined) {
      if (b.note !== null && typeof b.note !== 'string') {
        return Response.json({ error: 'یادداشت باید متن باشد' }, { status: 400 })
      }
      data.note = b.note === null ? null : b.note
    }

    if (b.completed !== undefined) {
      if (typeof b.completed !== 'boolean') {
        return Response.json({ error: 'وضعیت انجام باید بولی باشد' }, { status: 400 })
      }
      data.completed = b.completed
    }

    const block = await db.scheduleBlock.update({ where: { id }, data })
    return Response.json({ block })
  } catch {
    return Response.json({ error: 'خطای سرور' }, { status: 500 })
  }
}

export async function DELETE(_request: Request, { params }: Ctx) {
  try {
    const { id } = await params
    const existing = await db.scheduleBlock.findUnique({ where: { id } })
    if (!existing) {
      return Response.json({ error: 'بلوک زمانی یافت نشد' }, { status: 404 })
    }
    await db.scheduleBlock.delete({ where: { id } })
    return Response.json({ ok: true })
  } catch {
    return Response.json({ error: 'خطای سرور' }, { status: 500 })
  }
}
