import type { Metadata, Viewport } from "next";
import { Vazirmatn } from "next/font/google";
import "./globals.css";
import { Providers } from "@/components/stepbystep/providers";

const vazirmatn = Vazirmatn({
  subsets: ["arabic", "latin"],
  variable: "--font-vazirmatn",
  display: "swap",
});

export const metadata: Metadata = {
  title: "قدم به قدم | برنامه‌ریز روزانه",
  description:
    "ابزار آنلاین برنامه‌ریزی روزانه، مدیریت وظایف، ایجاد عادت‌های مفید و بررسی پیشرفت فردی — برنامه مطالعه، تکالیف مدرسه، ورزش، استراحت و اهداف هفتگی.",
  keywords: [
    "برنامه‌ریزی روزانه",
    "مدیریت وظایف",
    "عادت‌های مفید",
    "اهداف هفتگی",
    "قدم به قدم",
    "برنامه مطالعه",
  ],
};

export const viewport: Viewport = {
  themeColor: [
    { media: "(prefers-color-scheme: light)", color: "#f7fdf9" },
    { media: "(prefers-color-scheme: dark)", color: "#0c1512" },
  ],
};

export default function RootLayout({
  children,
}: Readonly<{
  children: React.ReactNode;
}>) {
  return (
    <html lang="fa" dir="rtl" suppressHydrationWarning>
      <body
        className={`${vazirmatn.variable} font-sans antialiased bg-background text-foreground`}
      >
        <Providers>{children}</Providers>
      </body>
    </html>
  );
}
