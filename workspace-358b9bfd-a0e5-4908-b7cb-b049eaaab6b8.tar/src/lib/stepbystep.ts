// قدم به قدم — shared types, constants & Persian (Jalali) helpers

export type Category = "study" | "homework" | "exercise" | "rest" | "other";
export type Priority = "low" | "medium" | "high";

export interface Task {
  id: string;
  title: string;
  description: string | null;
  category: string;
  priority: string;
  dueDate: string | null;
  completed: boolean;
  completedAt: string | null;
  createdAt: string;
  updatedAt: string;
}

export interface ScheduleBlock {
  id: string;
  date: string;
  startTime: string;
  endTime: string;
  title: string;
  category: string;
  note: string | null;
  completed: boolean;
  createdAt: string;
}

export interface HabitLog {
  id: string;
  habitId: string;
  date: string;
  createdAt: string;
}

export interface Habit {
  id: string;
  title: string;
  icon: string;
  targetDays: number;
  createdAt: string;
  logs: HabitLog[];
}

export interface Goal {
  id: string;
  title: string;
  target: number;
  progress: number;
  unit: string;
  weekStart: string;
  createdAt: string;
}

export interface DayCount {
  date: string;
  count: number;
}

export interface HabitStreak {
  habitId: string;
  title: string;
  icon: string;
  streak: number;
}

export interface Stats {
  taskTotal: number;
  taskCompleted: number;
  taskDueToday: number;
  tasksCompletedLast7: DayCount[];
  habitLogsLast7: DayCount[];
  habitCount: number;
  habitLogsThisWeek: number;
  habitPlannedThisWeek: number;
  goals: Goal[];
  streaks: HabitStreak[];
}

export type TabId =
  | "dashboard"
  | "schedule"
  | "tasks"
  | "habits"
  | "goals"
  | "progress";

export const NAV_TABS: { id: TabId; label: string }[] = [
  { id: "dashboard", label: "داشبورد" },
  { id: "schedule", label: "برنامه روزانه" },
  { id: "tasks", label: "وظایف" },
  { id: "habits", label: "عادت‌ها" },
  { id: "goals", label: "اهداف هفتگی" },
  { id: "progress", label: "پیشرفت" },
];

/* ---------------------------------- categories ---------------------------------- */

export const CATEGORIES: Record<
  Category,
  { label: string; emoji: string; badge: string; dot: string; soft: string }
> = {
  study: {
    label: "مطالعه",
    emoji: "📚",
    badge: "bg-emerald-100 text-emerald-800 dark:bg-emerald-950 dark:text-emerald-300",
    dot: "bg-emerald-500",
    soft: "bg-emerald-50 dark:bg-emerald-950/40",
  },
  homework: {
    label: "تکالیف مدرسه",
    emoji: "✏️",
    badge: "bg-amber-100 text-amber-800 dark:bg-amber-950 dark:text-amber-300",
    dot: "bg-amber-500",
    soft: "bg-amber-50 dark:bg-amber-950/40",
  },
  exercise: {
    label: "ورزش",
    emoji: "🏃",
    badge: "bg-teal-100 text-teal-800 dark:bg-teal-950 dark:text-teal-300",
    dot: "bg-teal-500",
    soft: "bg-teal-50 dark:bg-teal-950/40",
  },
  rest: {
    label: "استراحت",
    emoji: "☕",
    badge: "bg-orange-100 text-orange-800 dark:bg-orange-950 dark:text-orange-300",
    dot: "bg-orange-500",
    soft: "bg-orange-50 dark:bg-orange-950/40",
  },
  other: {
    label: "دیگر",
    emoji: "🎯",
    badge: "bg-stone-100 text-stone-700 dark:bg-stone-800 dark:text-stone-300",
    dot: "bg-stone-500",
    soft: "bg-stone-50 dark:bg-stone-900/40",
  },
};

export const CATEGORY_LIST = Object.keys(CATEGORIES) as Category[];

export function categoryInfo(cat: string) {
  return CATEGORIES[cat as Category] ?? CATEGORIES.other;
}

export const PRIORITIES: Record<Priority, { label: string; badge: string }> = {
  low: {
    label: "کم",
    badge: "bg-stone-100 text-stone-600 dark:bg-stone-800 dark:text-stone-300",
  },
  medium: {
    label: "متوسط",
    badge: "bg-amber-100 text-amber-800 dark:bg-amber-950 dark:text-amber-300",
  },
  high: {
    label: "زیاد",
    badge: "bg-red-100 text-red-700 dark:bg-red-950 dark:text-red-300",
  },
};

export const HABIT_ICONS = [
  "🌱", "📚", "🏃", "💧", "🧘", "🌙", "☀️", "🎨", "🎸", "✍️",
  "🥗", "🚴", "🕌", "📖", "🧹", "💪", "🧠", "⏰",
];

export const GOAL_UNITS = ["مرتبه", "ساعت", "صفحه", "جلسه", "کیلومتر", "تمرین"];

/* ---------------------------------- dates ---------------------------------- */

/** Persian day names indexed by JS getDay() (0=Sunday … 6=Saturday) */
export const DAY_NAMES_FA = [
  "یکشنبه", "دوشنبه", "سه‌شنبه", "چهارشنبه", "پنجشنبه", "جمعه", "شنبه",
];

/** Short column names for the habit grid, ordered شنبه → جمعه */
export const WEEK_COLUMNS_FA = ["ش", "ی", "د", "س", "چ", "پ", "ج"];

/** yyyy-mm-dd in local time */
export function toISO(date: Date): string {
  const y = date.getFullYear();
  const m = String(date.getMonth() + 1).padStart(2, "0");
  const d = String(date.getDate()).padStart(2, "0");
  return `${y}-${m}-${d}`;
}

export function todayISO(): string {
  return toISO(new Date());
}

export function fromISO(iso: string): Date {
  const [y, m, d] = iso.split("-").map(Number);
  return new Date(y, m - 1, d);
}

export function addDaysISO(iso: string, days: number): string {
  const d = fromISO(iso);
  d.setDate(d.getDate() + days);
  return toISO(d);
}

/** Saturday (شنبه) that starts the Persian week containing the given date */
export function weekStartISO(iso: string = todayISO()): string {
  const d = fromISO(iso);
  const diff = (d.getDay() + 1) % 7; // Sat=0, Sun=1, … Fri=6
  d.setDate(d.getDate() - diff);
  return toISO(d);
}

/** Array of 7 ISO dates شنبه → جمعه of the Persian week containing `iso` */
export function getPersianWeek(iso: string = todayISO()): string[] {
  const start = weekStartISO(iso);
  return Array.from({ length: 7 }, (_, i) => addDaysISO(start, i));
}

/** relative helpers for due dates */
export function dueLabel(dueDate: string): { text: string; tone: "over" | "today" | "soon" | "later" } {
  const today = todayISO();
  if (dueDate === today) return { text: "امروز", tone: "today" };
  if (dueDate === addDaysISO(today, 1)) return { text: "فردا", tone: "soon" };
  if (dueDate < today) return { text: `${toFaDigits(formatJalali(dueDate, { day: "numeric", month: "short" }))} — دیر شده`, tone: "over" };
  return { text: formatJalali(dueDate, { day: "numeric", month: "short" }), tone: "later" };
}

/* ---------------------------------- formatting ---------------------------------- */

/** Convert Latin digits to Persian digits */
export function toFaDigits(input: string | number): string {
  const fa = "۰۱۲۳۴۵۶۷۸۹";
  return String(input).replace(/[0-9]/g, (d) => fa[Number(d)]);
}

/** Format a Gregorian ISO date as Jalali via Intl */
export function formatJalali(
  iso: string,
  opts: Intl.DateTimeFormatOptions = { weekday: "long", day: "numeric", month: "long", year: "numeric" },
): string {
  return new Intl.DateTimeFormat("fa-IR", opts).format(fromISO(iso));
}

/** "۱۴:۳۰" style time display */
export function formatTimeFA(hhmm: string): string {
  return toFaDigits(hhmm);
}

/** Duration between two HH:mm times, e.g. "۱ ساعت و ۳۰ دقیقه" */
export function formatDuration(start: string, end: string): string {
  const [sh, sm] = start.split(":").map(Number);
  const [eh, em] = end.split(":").map(Number);
  let mins = eh * 60 + em - (sh * 60 + sm);
  if (mins <= 0) return "—";
  const h = Math.floor(mins / 60);
  const m = mins % 60;
  const parts: string[] = [];
  if (h > 0) parts.push(`${toFaDigits(h)} ساعت`);
  if (m > 0) parts.push(`${toFaDigits(m)} دقیقه`);
  return parts.join(" و ");
}

/** Current streak of a habit (consecutive days ending today; today optional) */
export function habitStreak(logs: { date: string }[]): number {
  const set = new Set(logs.map((l) => l.date));
  const today = todayISO();
  let cursor = set.has(today) ? today : addDaysISO(today, -1);
  if (!set.has(cursor)) return 0;
  let streak = 0;
  while (set.has(cursor)) {
    streak++;
    cursor = addDaysISO(cursor, -1);
  }
  return streak;
}

/** Count of logs within the Persian week containing `iso` */
export function logsInWeek(logs: { date: string }[], iso: string = todayISO()): number {
  const week = new Set(getPersianWeek(iso));
  return logs.filter((l) => week.has(l.date)).length;
}

/** Percentage 0..100 */
export function pct(progress: number, target: number): number {
  if (target <= 0) return 0;
  return Math.min(100, Math.round((progress / target) * 100));
}
