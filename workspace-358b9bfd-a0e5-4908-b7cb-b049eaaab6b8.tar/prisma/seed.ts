// Seed demo data for قدم به قدم — relative to "today" so the demo always looks fresh
import { PrismaClient } from "@prisma/client";

const db = new PrismaClient();

function iso(d: Date): string {
  const y = d.getFullYear();
  const m = String(d.getMonth() + 1).padStart(2, "0");
  const day = String(d.getDate()).padStart(2, "0");
  return `${y}-${m}-${day}`;
}

function addDays(n: number): string {
  const d = new Date();
  d.setDate(d.getDate() + n);
  return iso(d);
}

function weekStartSat(): string {
  const now = new Date();
  const diff = (now.getDay() + 1) % 7;
  const sat = new Date(now);
  sat.setDate(now.getDate() - diff);
  return iso(sat);
}

async function main() {
  await db.habitLog.deleteMany();
  await db.habit.deleteMany();
  await db.task.deleteMany();
  await db.scheduleBlock.deleteMany();
  await db.goal.deleteMany();

  // --- tasks ---
  const today = addDays(0);
  await db.task.createMany({
    data: [
      {
        title: "مرور فصل ۳ ریاضی برای امتحان",
        category: "study",
        priority: "high",
        dueDate: today,
      },
      {
        title: "حل تمرین‌های عربی درس ۵",
        category: "homework",
        priority: "medium",
        dueDate: today,
      },
      {
        title: "۳۰ دقیقه دویدن در پارک",
        category: "exercise",
        priority: "low",
        dueDate: addDays(1),
      },
      {
        title: "خواندن ۲۰ صفحه کتاب داستان",
        category: "study",
        priority: "medium",
        dueDate: today,
        completed: true,
        completedAt: new Date(),
      },
      {
        title: "مرتب کردن میز مطالعه",
        category: "other",
        priority: "low",
        dueDate: addDays(-1),
        completed: true,
        completedAt: new Date(Date.now() - 86400000),
      },
    ],
  });

  // --- schedule for today ---
  await db.scheduleBlock.createMany({
    data: [
      { date: today, startTime: "08:00", endTime: "09:30", title: "مطالعه ریاضی", category: "study", note: "فصل ۳ و تمرین‌های آن", completed: true },
      { date: today, startTime: "10:00", endTime: "11:00", title: "انجام تکلیف علوم", category: "homework" },
      { date: today, startTime: "16:30", endTime: "17:30", title: "ورزش و دویدن", category: "exercise" },
      { date: today, startTime: "21:00", endTime: "22:00", title: "مرور برنامه فردا", category: "other" },
      { date: today, startTime: "22:30", endTime: "23:00", title: "کتاب‌خوانی قبل از خواب", category: "rest" },
    ],
  });

  // --- habits with logs ---
  const h1 = await db.habit.create({ data: { title: "مطالعه روزانه", icon: "📚", targetDays: 7 } });
  const h2 = await db.habit.create({ data: { title: "نوشیدن ۸ لیوان آب", icon: "💧", targetDays: 7 } });
  const h3 = await db.habit.create({ data: { title: "ورزش صبحگاهی", icon: "🏃", targetDays: 5 } });
  const h4 = await db.habit.create({ data: { title: "خواب به موقع", icon: "🌙", targetDays: 6 } });

  const logs: { habitId: string; date: string }[] = [];
  for (let i = 0; i < 5; i++) logs.push({ habitId: h1.id, date: addDays(-i) });
  logs.push({ habitId: h2.id, date: addDays(0) });
  logs.push({ habitId: h2.id, date: addDays(-1) });
  logs.push({ habitId: h2.id, date: addDays(-2) });
  logs.push({ habitId: h3.id, date: addDays(-1) });
  logs.push({ habitId: h3.id, date: addDays(-2) });
  logs.push({ habitId: h4.id, date: addDays(-3) });
  logs.push({ habitId: h4.id, date: addDays(-4) });
  await db.habitLog.createMany({ data: logs });

  // --- weekly goals ---
  const ws = weekStartSat();
  await db.goal.createMany({
    data: [
      { title: "خواندن کتاب داستان", target: 50, progress: 20, unit: "صفحه", weekStart: ws },
      { title: "ورزش هفتگی", target: 4, progress: 1, unit: "مرتبه", weekStart: ws },
      { title: "جلسات تمرین ریاضی", target: 3, progress: 3, unit: "جلسه", weekStart: ws },
    ],
  });

  console.log("✅ Seed data created for قدم به قدم");
}

main()
  .catch((e) => {
    console.error(e);
    process.exit(1);
  })
  .finally(() => db.$disconnect());
