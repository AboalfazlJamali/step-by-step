# Worklog — قدم به قدم (Step by Step)

Project: Persian (RTL) daily planner web app — Next.js 16, TypeScript, Tailwind 4, shadcn/ui, Prisma + SQLite.

---
Task ID: 1
Agent: main orchestrator (Z.ai Code)
Task: Design Prisma schema and push database

Work Log:
- Replaced prisma/schema.prisma with domain models:
  - Task (title, description, category: study|homework|exercise|rest|other, priority: low|medium|high, dueDate yyyy-mm-dd, completed, completedAt)
  - ScheduleBlock (date yyyy-mm-dd, startTime/endTime HH:mm, title, category, note, completed) — indexed by date
  - Habit (title, icon emoji, targetDays per week) with HabitLog (unique habitId+date, date yyyy-mm-dd)
  - Goal (title, target, progress, unit, weekStart yyyy-mm-dd = Saturday, Persian week start)
- Removed scaffold User/Post models
- Ran `bun run db:push` — schema pushed to db/custom.db, Prisma Client generated

Stage Summary:
- DB layer ready at src/lib/db.ts (`import { db } from '@/lib/db'`)
- All dates stored as strings: dates "yyyy-mm-dd" (Gregorian ISO), times "HH:mm" 24h
- Jalali display is a UI-only concern (Intl.DateTimeFormat fa-IR); week starts on Saturday (شنبه)

## API CONTRACT (agreed for all agents — src/app/api)

All routes return JSON. Errors: `{ error: string }` with proper status codes (400 validation, 404 not found, 500).
Category values everywhere: "study" | "homework" | "exercise" | "rest" | "other".

1) /api/tasks
- GET  → { tasks: Task[] } — sorted: incomplete first, then priority high→low, then createdAt desc
- POST { title, description?, category?, priority?, dueDate? } → { task } (title required, 1..200 chars)
- PATCH /api/tasks/[id] { title?, description?, category?, priority?, dueDate?, completed? } → { task }
  - when completed set true → set completedAt=now; when false → completedAt=null
- DELETE /api/tasks/[id] → { ok: true }

2) /api/schedule
- GET ?date=yyyy-mm-dd → { blocks: ScheduleBlock[] } sorted by startTime; without date → 400
- POST { date, startTime, endTime, title, category?, note? } → { block } (endTime > startTime required)
- PATCH /api/schedule/[id] { date?, startTime?, endTime?, title?, category?, note?, completed? } → { block }
- DELETE /api/schedule/[id] → { ok: true }

3) /api/habits
- GET → { habits: (Habit & { logs: HabitLog[] })[] } — logs limited to last 35 days
- POST { title, icon?, targetDays? } → { habit } (with logs: []; targetDays 1..7)
- PATCH /api/habits/[id] { title?, icon?, targetDays? } → { habit } (with logs)
- DELETE /api/habits/[id] → { ok: true }
- POST /api/habits/[id]/toggle { date } → { habit } (with logs) — creates log if missing, deletes if exists

4) /api/goals
- GET ?weekStart=yyyy-mm-dd (optional; default = current Persian week Saturday) → { goals: Goal[], weekStart }
- POST { title, target?, unit?, weekStart? } → { goal } (target >= 1)
- PATCH /api/goals/[id] { title?, target?, progress?, unit? } → { goal } (progress clamped 0..target)
- DELETE /api/goals/[id] → { ok: true }

5) /api/stats
- GET → {
    taskTotal, taskCompleted, taskDueToday,
    tasksCompletedLast7: { date, count }[] (oldest→newest, all 7 days present),
    habitLogsLast7: { date, count }[] (same),
    habitCount, habitLogsThisWeek, habitPlannedThisWeek,
    goals: Goal[] (current week),
    streaks: { habitId, title, icon, streak }[]
  }

## FRONTEND CONTRACT

- Single route `/` (page.tsx renders `<StepByStepApp />` client component in src/components/stepbystep/)
- Tabs: داشبورد (dashboard) | برنامه روزانه (schedule) | وظایف (tasks) | عادت‌ها (habits) | اهداف هفتگی (goals) | پیشرفت (progress)
- Shared lib at src/lib/stepbystep.ts: types + Persian date/number helpers (toFaDigits, formatJalaliDate, getWeekDays, weekStartISO, todayISO, dayNamesFA, CATEGORY config incl. labels/icons/colors)
- Colors: emerald/teal primary, amber accents — NO blue/indigo. RTL, Vazirmatn font. Sticky footer, min-h-screen flex col.

---
Task ID: 2-a
Agent: API routes subagent
Task: Implement REST API routes (tasks, schedule, habits, goals, stats)

Work Log:
- Read worklog.md API contract, prisma/schema.prisma and src/lib/db.ts
- Created src/app/api/tasks/route.ts: GET (manual JS sort: incomplete first → priority high>medium>low → createdAt desc), POST (title 1..200 required, category default "other", priority default "medium", dueDate regex-validated, 201 { task })
- Created src/app/api/tasks/[id]/route.ts: PATCH (only provided fields; completed=true → completedAt=now, false → null; 404 "وظیفه یافت نشد"), DELETE ({ ok: true })
- Created src/app/api/schedule/route.ts: GET (?date required, regex yyyy-mm-dd, else 400 "پارامتر date الزامی است"; blocks sorted startTime asc), POST (endTime > startTime enforced, else 400 "ساعت پایان باید بعد از ساعت شروع باشد"; time range 00..23/00..59 checked; category default "study")
- Created src/app/api/schedule/[id]/route.ts: PATCH (partial update, validates effective start<end when times change), DELETE
- Created src/app/api/habits/route.ts: GET (logs include where date >= today-35, orderBy date desc), POST (icon default "🌱", targetDays default 7 clamped 1..7, returns habit with logs)
- Created src/app/api/habits/[id]/route.ts: PATCH (clamps targetDays, returns habit with 35-day logs), DELETE (cascade removes logs)
- Created src/app/api/habits/[id]/toggle/route.ts: POST { date } — finds log by unique habitId_date, deletes if exists else creates; returns habit with logs; 404 if habit missing
- Created src/app/api/goals/route.ts: GET (?weekStart optional, default = current Persian week Saturday via (getDay()+1)%7; goals sorted createdAt asc), POST (target default 1 clamped 1..10000, unit default "مرتبه")
- Created src/app/api/goals/[id]/route.ts: PATCH (progress clamped 0..effectiveTarget — new target if provided else existing), DELETE
- Created src/app/api/stats/route.ts (export const dynamic = "force-dynamic"): taskTotal/taskCompleted/taskDueToday (dueDate===today & not completed); tasksCompletedLast7 + habitLogsLast7 grouped in JS over today-6…today using local-date formatter (getFullYear/getMonth/getDate, NOT UTC); habitCount, habitLogsThisWeek (Sat..Fri range), habitPlannedThisWeek (sum targetDays); goals of current week; streaks for ALL habits (consecutive days ending today if logged else yesterday, computed with local date arithmetic on "yyyy-mm-dd" strings)
- All handlers wrapped in try/catch → 500 { error: "خطای سرور" }; manual validation (no zod); Persian error messages; params awaited as Promise per Next.js 16
- Ran `bunx tsc --noEmit` → zero errors in src/app/api (remaining errors are pre-existing in examples/ and skills/ dirs, out of scope)
- Ran `bunx eslint src/app/api` → clean, no warnings

Stage Summary:
- 10 route files implemented exactly per API CONTRACT: /api/tasks, /api/tasks/[id], /api/schedule, /api/schedule/[id], /api/habits, /api/habits/[id], /api/habits/[id]/toggle, /api/goals, /api/goals/[id], /api/stats
- All responses JSON per contract: success shapes { tasks } { task } { blocks } { habit } { goals, weekStart } { ok: true } and full stats payload; errors { error } with 400/404/500
- Dates kept as "yyyy-mm-dd" strings, times "HH:mm"; Persian week = Saturday start; habit log window = 35 days
- No pages/components touched; no dev server started; ready for frontend agent (Task 2-b) to consume

---
Task ID: 2-b, 3, 4
Agent: main orchestrator (Z.ai Code)
Task: Shared lib, full frontend UI, seeding, lint & browser verification

Work Log:
- Created src/lib/stepbystep.ts: types (Task/Habit/HabitLog/Goal/ScheduleBlock/Stats), TabId + NAV_TABS, CATEGORIES/PRIORITIES config (emerald/amber/teal/orange palette), Jalali helpers (toISO, fromISO, addDaysISO, weekStartISO Saturday-anchored, getPersianWeek, formatJalali via Intl fa-IR, toFaDigits, formatDuration, habitStreak, logsInWeek, dueLabel, pct)
- layout.tsx: lang=fa dir=rtl, Vazirmatn via next/font/google (arabic+latin), metadata in Persian, viewport themeColor
- providers.tsx: next-themes ThemeProvider + sonner Toaster (richColors, top-center, rtl)
- globals.css: emerald/teal oklch theme (light+dark), no blue/indigo, thin scrollbars, LTR time/number inputs
- app.tsx: client shell — splash screen until mount (useSyncExternalStore mount flag, no setState-in-effect), sticky header + sticky pill nav, 6 tabs, optimistic CRUD for tasks/schedule/habits/goals + stats refetch, sonner toasts, footer mt-auto with safe-area padding
- views/dashboard.tsx: hero greeting + weekday motivation + 3 hero stats, today tasks/schedule/habits/goals cards with quick actions, clickable week strip with per-day indicators
- views/tasks.tsx: add form (category/priority selects, due chips امروز/فردا/پس‌فردا/بدون مهلت), status + category filters, task list with badges (category/priority/due incl. دیر شده red), delete
- views/schedule.tsx: date nav (prev/next/امروز), add activity form with time inputs + presets, timeline with colored time column, duration, note, done toggle, delete
- views/habits.tsx: add habit (18-emoji icon picker, target-days chips), weekly grid table شنبه→جمعه with toggles, today ring highlight, streak 🔥 column, weekly totals
- views/goals.tsx: week header, add form (target number + unit datalist), goal cards with progress bars and +/- buttons, completion badge 🎉
- views/progress.tsx: 4 stat cards, 2 recharts bar charts (7-day tasks/habits, reversed axis for RTL time flow, Persian tooltips), streaks list, goals summary
- prisma/seed.ts: idempotent demo data relative to today (5 tasks, 5 schedule blocks, 4 habits + logs, 3 goals)
- Fixed react-hooks/set-state-in-effect lint errors (mount flag + inline async effect loaders with cancellation)
- Fixed GoalCard closure bug (actions prop) and habit grid day-name mapping (fromISO getDay)
- Verified with Agent Browser end-to-end: dashboard render, task add/toggle/delete + filters, schedule add/toggle/delete + date nav + بازگشت به امروز, habit grid toggles + streaks, goal increment (1/4→2/4, 25%→50%), charts data alignment (bars match labels, RTL reversed axis), dark mode, mobile 390px, sticky footer, zero console/page errors, dev.log clean

Stage Summary:
- App is complete and browser-verified at / — all 6 sections interactive, RTL Persian (Vazirmatn), Jalali dates, emerald theme, light/dark, responsive
- Task IDs completed: 2-b (lib), 3 (frontend), 3-b (seed), 4 (verification); lint clean, tsc clean (src)
